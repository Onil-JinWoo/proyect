using System;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class EliminarProducto : Form
    {
        public EliminarProducto()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Eliminar();
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                Eliminar();
            }
        }

        private void Eliminar()
        {
            string codigo = txtCodigo == null ? string.Empty : txtCodigo.Text.Trim();
            if (string.IsNullOrWhiteSpace(codigo))
            {
                MessageBox.Show("Ingrese el código de barras.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtCodigo != null)
                    txtCodigo.Focus();
                return;
            }

            ProductoInfo p = DatabaseHelper.ObtenerProductoPorCodigoBarras(codigo);
            if (p == null)
            {
                MessageBox.Show("Producto no encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtCodigo != null)
                {
                    txtCodigo.SelectAll();
                    txtCodigo.Focus();
                }
                return;
            }

            DialogResult r = MessageBox.Show(
                string.Format("¿Eliminar el producto '{0}'?", p.Descripcion),
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (r != DialogResult.Yes)
                return;

            if (DatabaseHelper.EliminarProductoPorIdProducto(p.IdProducto))
            {
                MessageBox.Show("Producto eliminado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                productos mod = ObtenerModuloProductos();
                if (mod != null)
                {
                    mod.NavegarANuevo();
                    return;
                }

                Form1 main = ObtenerFormPrincipal();
                if (main != null)
                {
                    main.MostrarProductos();
                    return;
                }

                this.Close();
            }
        }

        private Form1 ObtenerFormPrincipal()
        {
            Form1 main = this.TopLevelControl as Form1;
            if (main != null)
                return main;

            Control c = this.Parent;
            while (c != null)
            {
                Form1 f = c as Form1;
                if (f != null)
                    return f;
                c = c.Parent;
            }

            return null;
        }

        private productos ObtenerModuloProductos()
        {
            Control c = this.Parent;
            while (c != null)
            {
                productos p = c as productos;
                if (p != null)
                    return p;
                c = c.Parent;
            }

            return null;
        }
    }
}
