namespace Abarrote
{
    partial class InventarioUserControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            this.lblInventarioTitle = new System.Windows.Forms.Label();
            this.pnlActionBar = new System.Windows.Forms.Panel();
            this.btnKardex = new System.Windows.Forms.Button();
            this.btnReporteMovimientos = new System.Windows.Forms.Button();
            this.btnReporteInventario = new System.Windows.Forms.Button();
            this.btnProductosBajos = new System.Windows.Forms.Button();
            this.btnAjustes = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.pnlAgregarInventario = new System.Windows.Forms.Panel();
            this.txtCodigoProducto = new System.Windows.Forms.TextBox();
            this.lblCodigoProducto = new System.Windows.Forms.Label();
            this.lblAgregarInventario = new System.Windows.Forms.Label();
            this.pnlActionBar.SuspendLayout();
            this.pnlAgregarInventario.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblInventarioTitle
            // 
            this.lblInventarioTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(80)))), ((int)(((byte)(160)))));
            this.lblInventarioTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblInventarioTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblInventarioTitle.ForeColor = System.Drawing.Color.White;
            this.lblInventarioTitle.Location = new System.Drawing.Point(10, 10);
            this.lblInventarioTitle.Name = "lblInventarioTitle";
            this.lblInventarioTitle.Padding = new System.Windows.Forms.Padding(8, 5, 0, 5);
            this.lblInventarioTitle.Size = new System.Drawing.Size(1282, 35);
            this.lblInventarioTitle.TabIndex = 0;
            this.lblInventarioTitle.Text = "INVENTARIO";
            this.lblInventarioTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlActionBar
            // 
            this.pnlActionBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(245)))));
            this.pnlActionBar.Controls.Add(this.btnKardex);
            this.pnlActionBar.Controls.Add(this.btnReporteMovimientos);
            this.pnlActionBar.Controls.Add(this.btnReporteInventario);
            this.pnlActionBar.Controls.Add(this.btnProductosBajos);
            this.pnlActionBar.Controls.Add(this.btnAjustes);
            this.pnlActionBar.Controls.Add(this.btnAgregar);
            this.pnlActionBar.Location = new System.Drawing.Point(15, 48);
            this.pnlActionBar.Name = "pnlActionBar";
            this.pnlActionBar.Size = new System.Drawing.Size(900, 40);
            this.pnlActionBar.TabIndex = 1;
            // 
            // btnKardex
            // 
            this.btnKardex.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnKardex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKardex.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnKardex.Location = new System.Drawing.Point(690, 5);
            this.btnKardex.Name = "btnKardex";
            this.btnKardex.Size = new System.Drawing.Size(150, 30);
            this.btnKardex.TabIndex = 5;
            this.btnKardex.Text = "Kardex de inventario";
            this.btnKardex.UseVisualStyleBackColor = true;
            // 
            // btnReporteMovimientos
            // 
            this.btnReporteMovimientos.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnReporteMovimientos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReporteMovimientos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnReporteMovimientos.Location = new System.Drawing.Point(525, 5);
            this.btnReporteMovimientos.Name = "btnReporteMovimientos";
            this.btnReporteMovimientos.Size = new System.Drawing.Size(160, 30);
            this.btnReporteMovimientos.TabIndex = 4;
            this.btnReporteMovimientos.Text = "Reporte de Movimientos";
            this.btnReporteMovimientos.UseVisualStyleBackColor = true;
            // 
            // btnReporteInventario
            // 
            this.btnReporteInventario.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnReporteInventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReporteInventario.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnReporteInventario.Location = new System.Drawing.Point(370, 5);
            this.btnReporteInventario.Name = "btnReporteInventario";
            this.btnReporteInventario.Size = new System.Drawing.Size(150, 30);
            this.btnReporteInventario.TabIndex = 3;
            this.btnReporteInventario.Text = "Reporte de Inventario";
            this.btnReporteInventario.UseVisualStyleBackColor = true;
            // 
            // btnProductosBajos
            // 
            this.btnProductosBajos.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnProductosBajos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductosBajos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnProductosBajos.Location = new System.Drawing.Point(185, 5);
            this.btnProductosBajos.Name = "btnProductosBajos";
            this.btnProductosBajos.Size = new System.Drawing.Size(180, 30);
            this.btnProductosBajos.TabIndex = 2;
            this.btnProductosBajos.Text = "Productos bajos en Inventario";
            this.btnProductosBajos.UseVisualStyleBackColor = true;
            // 
            // btnAjustes
            // 
            this.btnAjustes.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnAjustes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAjustes.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAjustes.Location = new System.Drawing.Point(100, 5);
            this.btnAjustes.Name = "btnAjustes";
            this.btnAjustes.Size = new System.Drawing.Size(80, 30);
            this.btnAjustes.TabIndex = 1;
            this.btnAjustes.Text = "Ajustes";
            this.btnAjustes.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(5, 5);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(90, 30);
            this.btnAgregar.TabIndex = 0;
            this.btnAgregar.Text = "+ Agregar";
            this.btnAgregar.UseVisualStyleBackColor = false;
            // 
            // pnlAgregarInventario
            // 
            this.pnlAgregarInventario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlAgregarInventario.BackColor = System.Drawing.Color.White;
            this.pnlAgregarInventario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAgregarInventario.Controls.Add(this.txtCodigoProducto);
            this.pnlAgregarInventario.Controls.Add(this.lblCodigoProducto);
            this.pnlAgregarInventario.Controls.Add(this.lblAgregarInventario);
            this.pnlAgregarInventario.Location = new System.Drawing.Point(15, 98);
            this.pnlAgregarInventario.Name = "pnlAgregarInventario";
            this.pnlAgregarInventario.Padding = new System.Windows.Forms.Padding(20);
            this.pnlAgregarInventario.Size = new System.Drawing.Size(1018, 255);
            this.pnlAgregarInventario.TabIndex = 2;
            // 
            // txtCodigoProducto
            // 
            this.txtCodigoProducto.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtCodigoProducto.Location = new System.Drawing.Point(135, 62);
            this.txtCodigoProducto.Name = "txtCodigoProducto";
            this.txtCodigoProducto.Size = new System.Drawing.Size(350, 25);
            this.txtCodigoProducto.TabIndex = 2;
            // 
            // lblCodigoProducto
            // 
            this.lblCodigoProducto.AutoSize = true;
            this.lblCodigoProducto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCodigoProducto.Location = new System.Drawing.Point(23, 65);
            this.lblCodigoProducto.Name = "lblCodigoProducto";
            this.lblCodigoProducto.Size = new System.Drawing.Size(120, 15);
            this.lblCodigoProducto.TabIndex = 1;
            this.lblCodigoProducto.Text = "Código del Producto:";
            // 
            // lblAgregarInventario
            // 
            this.lblAgregarInventario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(80)))), ((int)(((byte)(160)))));
            this.lblAgregarInventario.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAgregarInventario.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblAgregarInventario.ForeColor = System.Drawing.Color.White;
            this.lblAgregarInventario.Location = new System.Drawing.Point(20, 20);
            this.lblAgregarInventario.Name = "lblAgregarInventario";
            this.lblAgregarInventario.Padding = new System.Windows.Forms.Padding(5);
            this.lblAgregarInventario.Size = new System.Drawing.Size(976, 28);
            this.lblAgregarInventario.TabIndex = 0;
            this.lblAgregarInventario.Text = "AGREGAR INVENTARIO";
            this.lblAgregarInventario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // InventarioUserControl
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.Controls.Add(this.pnlAgregarInventario);
            this.Controls.Add(this.pnlActionBar);
            this.Controls.Add(this.lblInventarioTitle);
            this.Name = "InventarioUserControl";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(1302, 373);
            this.pnlActionBar.ResumeLayout(false);
            this.pnlAgregarInventario.ResumeLayout(false);
            this.pnlAgregarInventario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblInventarioTitle;
        private System.Windows.Forms.Panel pnlActionBar;
        private System.Windows.Forms.Button btnKardex;
        private System.Windows.Forms.Button btnReporteMovimientos;
        private System.Windows.Forms.Button btnReporteInventario;
        private System.Windows.Forms.Button btnProductosBajos;
        private System.Windows.Forms.Button btnAjustes;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Panel pnlAgregarInventario;
        private System.Windows.Forms.TextBox txtCodigoProducto;
        private System.Windows.Forms.Label lblCodigoProducto;
        private System.Windows.Forms.Label lblAgregarInventario;
    }
}
