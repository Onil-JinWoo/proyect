using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class CommonProductForm : Form
    {
        private Panel _hdr;
        private Label _lblHdr;
        private Label _lblDesc;
        private TextBox _txtDesc;
        private Label _lblCantidad;
        private NumericUpDown _nudCantidad;
        private Label _lblPrecio;
        private TextBox _txtPrecio;
        private Button _btnAceptar;
        private Button _btnCancelar;

        public string Descripcion { get; private set; }
        public int Cantidad { get; private set; }
        public decimal Precio { get; private set; }

        public CommonProductForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Producto Común";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(520, 190);

            _hdr = new Panel();
            _hdr.Location = new Point(0, 0);
            _hdr.Size = new Size(520, 30);
            _hdr.BackColor = Color.FromArgb(70, 130, 180);

            _lblHdr = new Label();
            _lblHdr.AutoSize = false;
            _lblHdr.Location = new Point(10, 5);
            _lblHdr.Size = new Size(360, 20);
            _lblHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            _lblHdr.ForeColor = Color.White;
            _lblHdr.Text = "PRODUCTO COMÚN";

            _hdr.Controls.Add(_lblHdr);

            _lblDesc = new Label();
            _lblDesc.AutoSize = true;
            _lblDesc.Location = new Point(20, 45);
            _lblDesc.Font = new Font("Segoe UI", 9F);
            _lblDesc.Text = "Descripción del Producto:";

            _txtDesc = new TextBox();
            _txtDesc.Location = new Point(20, 65);
            _txtDesc.Size = new Size(340, 23);
            _txtDesc.Text = "Producto común";

            _lblCantidad = new Label();
            _lblCantidad.AutoSize = true;
            _lblCantidad.Location = new Point(20, 100);
            _lblCantidad.Font = new Font("Segoe UI", 9F);
            _lblCantidad.Text = "Cantidad:";

            _nudCantidad = new NumericUpDown();
            _nudCantidad.Location = new Point(20, 120);
            _nudCantidad.Size = new Size(150, 23);
            _nudCantidad.Minimum = 1;
            _nudCantidad.Maximum = 100000;
            _nudCantidad.DecimalPlaces = 0;
            _nudCantidad.Value = 1;

            _lblPrecio = new Label();
            _lblPrecio.AutoSize = true;
            _lblPrecio.Location = new Point(220, 100);
            _lblPrecio.Font = new Font("Segoe UI", 9F);
            _lblPrecio.Text = "Precio:";

            _txtPrecio = new TextBox();
            _txtPrecio.Location = new Point(220, 120);
            _txtPrecio.Size = new Size(140, 23);
            _txtPrecio.Text = 0m.ToString("C2", CultureInfo.CurrentCulture);
            _txtPrecio.Enter += (s, e) =>
            {
                if (_txtPrecio != null)
                    _txtPrecio.SelectAll();
            };

            _btnAceptar = new Button();
            _btnAceptar.Location = new Point(390, 55);
            _btnAceptar.Size = new Size(110, 32);
            _btnAceptar.Text = "Aceptar";
            _btnAceptar.Click += btnAceptar_Click;

            _btnCancelar = new Button();
            _btnCancelar.Location = new Point(390, 95);
            _btnCancelar.Size = new Size(110, 32);
            _btnCancelar.Text = "Cancelar";
            _btnCancelar.Click += btnCancelar_Click;

            AcceptButton = _btnAceptar;
            CancelButton = _btnCancelar;

            Controls.Add(_hdr);
            Controls.Add(_lblDesc);
            Controls.Add(_txtDesc);
            Controls.Add(_lblCantidad);
            Controls.Add(_nudCantidad);
            Controls.Add(_lblPrecio);
            Controls.Add(_txtPrecio);
            Controls.Add(_btnAceptar);
            Controls.Add(_btnCancelar);
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string desc = _txtDesc == null ? string.Empty : (_txtDesc.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(desc))
            {
                MessageBox.Show("Captura la descripción del producto.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtDesc != null) _txtDesc.Focus();
                return;
            }

            decimal precio;
            if (!TryParseMonto(_txtPrecio == null ? string.Empty : (_txtPrecio.Text ?? string.Empty), out precio) || precio < 0m)
            {
                MessageBox.Show("Captura un precio válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtPrecio != null)
                {
                    _txtPrecio.SelectAll();
                    _txtPrecio.Focus();
                }
                return;
            }

            Descripcion = desc;
            Cantidad = (int)(_nudCantidad == null ? 1 : _nudCantidad.Value);
            Precio = precio;

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private static bool TryParseMonto(string value, out decimal monto)
        {
            monto = 0m;
            string v = (value ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(v))
                return false;

            if (decimal.TryParse(v, NumberStyles.Currency, CultureInfo.CurrentCulture, out monto))
                return true;

            return decimal.TryParse(v, NumberStyles.Number, CultureInfo.CurrentCulture, out monto);
        }
    }
}
