using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class LoginForm : Form
    {
        private PictureBox _pic;
        private Label _lblTitle;
        private Label _lblIntro;
        private Label _lblUsuario;
        private ComboBox _cboUsuario;
        private Label _lblContrasena;
        private TextBox _txtContrasena;
        private LinkLabel _lnkOlvide;
        private LinkLabel _lnkCrearCuenta;
        private Button _btnAcceder;
        private Button _btnSalir;
        private Panel _pnlBottom;
        private PictureBox _picInfo;
        private Label _lblBottom;

        public string UsuarioSeleccionado
        {
            get
            {
                return _cboUsuario == null ? string.Empty : (_cboUsuario.Text ?? string.Empty).Trim();
            }
        }

        public LoginForm()
        {
            InitializeUi();
            CargarUsuarios();
        }

        private void InitializeUi()
        {
            Text = "eleventa - Comenzar Nuevo Turno";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = true;
            ClientSize = new Size(520, 240);

            _pic = new PictureBox();
            _pic.Location = new Point(15, 18);
            _pic.Size = new Size(64, 64);
            _pic.SizeMode = PictureBoxSizeMode.Zoom;
            _pic.Image = SystemIcons.Information.ToBitmap();

            _lblTitle = new Label();
            _lblTitle.AutoSize = false;
            _lblTitle.Location = new Point(90, 10);
            _lblTitle.Size = new Size(410, 30);
            _lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            _lblTitle.ForeColor = Color.FromArgb(0, 0, 192);
            _lblTitle.Text = "Comenzar nuevo turno";

            _lblIntro = new Label();
            _lblIntro.AutoSize = false;
            _lblIntro.Location = new Point(90, 45);
            _lblIntro.Size = new Size(410, 35);
            _lblIntro.Font = new Font("Segoe UI", 9F);
            _lblIntro.Text = "Por favor ingresa tu usuario y contraseña para\r\ncontinuar.";

            _lblUsuario = new Label();
            _lblUsuario.AutoSize = true;
            _lblUsuario.Location = new Point(90, 90);
            _lblUsuario.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblUsuario.Text = "Usuario:";

            _cboUsuario = new ComboBox();
            _cboUsuario.DropDownStyle = ComboBoxStyle.DropDownList;
            _cboUsuario.Location = new Point(160, 86);
            _cboUsuario.Size = new Size(260, 24);

            _lblContrasena = new Label();
            _lblContrasena.AutoSize = true;
            _lblContrasena.Location = new Point(90, 125);
            _lblContrasena.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblContrasena.Text = "Contraseña:";

            _txtContrasena = new TextBox();
            _txtContrasena.Location = new Point(160, 121);
            _txtContrasena.Size = new Size(260, 24);
            _txtContrasena.UseSystemPasswordChar = true;

            _lnkOlvide = new LinkLabel();
            _lnkOlvide.AutoSize = true;
            _lnkOlvide.Location = new Point(430, 125);
            _lnkOlvide.Text = "Olvidé mi contraseña";
            _lnkOlvide.LinkClicked += lnkOlvide_LinkClicked;

            _lnkCrearCuenta = new LinkLabel();
            _lnkCrearCuenta.AutoSize = true;
            _lnkCrearCuenta.Location = new Point(160, 145);
            _lnkCrearCuenta.Text = "Crear cuenta";
            _lnkCrearCuenta.LinkClicked += lnkCrearCuenta_LinkClicked;

            _btnAcceder = new Button();
            _btnAcceder.Location = new Point(160, 160);
            _btnAcceder.Size = new Size(170, 30);
            _btnAcceder.Text = "Acceder";
            _btnAcceder.Click += btnAcceder_Click;

            _btnSalir = new Button();
            _btnSalir.Location = new Point(340, 160);
            _btnSalir.Size = new Size(80, 30);
            _btnSalir.Text = "Salir";
            _btnSalir.Click += btnSalir_Click;

            AcceptButton = _btnAcceder;
            CancelButton = _btnSalir;

            _pnlBottom = new Panel();
            _pnlBottom.Location = new Point(15, 200);
            _pnlBottom.Size = new Size(490, 32);
            _pnlBottom.BorderStyle = BorderStyle.FixedSingle;
            _pnlBottom.BackColor = Color.FromArgb(255, 255, 225);

            _picInfo = new PictureBox();
            _picInfo.Location = new Point(6, 6);
            _picInfo.Size = new Size(20, 20);
            _picInfo.SizeMode = PictureBoxSizeMode.Zoom;
            _picInfo.Image = SystemIcons.Question.ToBitmap();

            _lblBottom = new Label();
            _lblBottom.AutoSize = false;
            _lblBottom.Location = new Point(32, 4);
            _lblBottom.Size = new Size(450, 24);
            _lblBottom.Font = new Font("Segoe UI", 8.5F);
            _lblBottom.Text = "Para entrar por primera vez, entra con el usuario \"admin\" y clave 12345.";

            _pnlBottom.Controls.Add(_picInfo);
            _pnlBottom.Controls.Add(_lblBottom);

            Controls.Add(_pic);
            Controls.Add(_lblTitle);
            Controls.Add(_lblIntro);
            Controls.Add(_lblUsuario);
            Controls.Add(_cboUsuario);
            Controls.Add(_lblContrasena);
            Controls.Add(_txtContrasena);
            Controls.Add(_lnkOlvide);
            Controls.Add(_lnkCrearCuenta);
            Controls.Add(_btnAcceder);
            Controls.Add(_btnSalir);
            Controls.Add(_pnlBottom);
        }

        private void btnAcceder_Click(object sender, EventArgs e)
        {
            string user = UsuarioSeleccionado;
            string pass = _txtContrasena == null ? string.Empty : (_txtContrasena.Text ?? string.Empty);

            if (!DatabaseHelper.ValidarLoginInicioSeccion(user, pass, true))
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtContrasena != null)
                {
                    _txtContrasena.SelectAll();
                    _txtContrasena.Focus();
                }
                return;
            }

            try
            {
                DataRow info = DatabaseHelper.ObtenerInfoUsuarioInicioSeccion(user, false);
                UserSessionState.Usuario = user;
                if (info != null)
                {
                    object n = info["Nombre"];
                    UserSessionState.Nombre = n == null || n == DBNull.Value ? string.Empty : n.ToString();
                }
                else
                {
                    UserSessionState.Nombre = string.Empty;
                }
            }
            catch
            {
                UserSessionState.Usuario = user;
                UserSessionState.Nombre = string.Empty;
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void lnkOlvide_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Si olvidaste tu contraseña, pide al administrador que la restablezca.", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lnkCrearCuenta_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (RegisterForm rf = new RegisterForm())
            {
                if (rf.ShowDialog(this) == DialogResult.OK)
                {
                    CargarUsuarios(rf.UsuarioCreado);
                    if (_txtContrasena != null)
                    {
                        _txtContrasena.Clear();
                        _txtContrasena.Focus();
                    }
                }
            }
        }

        private void CargarUsuarios(string seleccionarUsuario = null)
        {
            if (_cboUsuario == null)
                return;

            _cboUsuario.Items.Clear();

            DataTable dt = DatabaseHelper.ObtenerUsuariosInicioSeccion(true, false);
            if (dt != null)
            {
                foreach (DataRow row in dt.Rows)
                {
                    object u = row["Usuario"];
                    if (u != null && u != DBNull.Value)
                        _cboUsuario.Items.Add(u.ToString());
                }
            }

            if (_cboUsuario.Items.Count == 0)
                _cboUsuario.Items.Add("admin");

            if (!string.IsNullOrWhiteSpace(seleccionarUsuario))
            {
                int idx = _cboUsuario.Items.IndexOf(seleccionarUsuario);
                if (idx >= 0)
                    _cboUsuario.SelectedIndex = idx;
                else
                    _cboUsuario.SelectedIndex = 0;
            }
            else
            {
                _cboUsuario.SelectedIndex = 0;
            }

            if (_lblBottom != null)
                _lblBottom.Text = "Si es tu primera vez, crea tu cuenta con el enlace 'Crear cuenta'.";
        }
    }
}
