using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abarrote
{
    // Se usa como vista dentro de Form1 (en pnlMainContent)
    public partial class factura : UserControl
    {
        public factura()
        {
            InitializeComponent();
        }
    }
}
