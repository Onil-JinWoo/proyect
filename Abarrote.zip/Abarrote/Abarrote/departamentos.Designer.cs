namespace Abarrote
{
    partial class departamentos
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dgvDepartamentos = new System.Windows.Forms.DataGridView();
            this.colIdDepartamento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnNuevoDepartamento = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.lblNuevoDepartamento = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnGuardarDepartamento = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartamentos)).BeginInit();
            this.SuspendLayout();
            
            this.dgvDepartamentos.AllowUserToAddRows = false;
            this.dgvDepartamentos.AllowUserToDeleteRows = false;
            this.dgvDepartamentos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvDepartamentos.BackgroundColor = System.Drawing.Color.White;
            this.dgvDepartamentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepartamentos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colIdDepartamento,
            this.colNombre});
            this.dgvDepartamentos.Location = new System.Drawing.Point(12, 12);
            this.dgvDepartamentos.MultiSelect = false;
            this.dgvDepartamentos.Name = "dgvDepartamentos";
            this.dgvDepartamentos.ReadOnly = true;
            this.dgvDepartamentos.RowHeadersVisible = false;
            this.dgvDepartamentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDepartamentos.Size = new System.Drawing.Size(320, 426);
            this.dgvDepartamentos.TabIndex = 0;
            
            this.colIdDepartamento.DataPropertyName = "IdDepartamento";
            this.colIdDepartamento.HeaderText = "Id";
            this.colIdDepartamento.Name = "colIdDepartamento";
            this.colIdDepartamento.ReadOnly = true;
            this.colIdDepartamento.Visible = false;
            
            this.colNombre.DataPropertyName = "Nombre";
            this.colNombre.HeaderText = "Departamento";
            this.colNombre.Name = "colNombre";
            this.colNombre.ReadOnly = true;
            this.colNombre.Width = 300;
            
            this.btnNuevoDepartamento.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNuevoDepartamento.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnNuevoDepartamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoDepartamento.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnNuevoDepartamento.Location = new System.Drawing.Point(350, 12);
            this.btnNuevoDepartamento.Name = "btnNuevoDepartamento";
            this.btnNuevoDepartamento.Size = new System.Drawing.Size(170, 28);
            this.btnNuevoDepartamento.TabIndex = 1;
            this.btnNuevoDepartamento.Text = "Nuevo Departamento";
            this.btnNuevoDepartamento.UseVisualStyleBackColor = true;
            this.btnNuevoDepartamento.Click += new System.EventHandler(this.btnNuevoDepartamento_Click);
            
            this.btnEliminar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEliminar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEliminar.Location = new System.Drawing.Point(530, 12);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(120, 28);
            this.btnEliminar.TabIndex = 2;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            
            this.lblNuevoDepartamento.AutoSize = true;
            this.lblNuevoDepartamento.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNuevoDepartamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(140)))), ((int)(((byte)(70)))));
            this.lblNuevoDepartamento.Location = new System.Drawing.Point(346, 70);
            this.lblNuevoDepartamento.Name = "lblNuevoDepartamento";
            this.lblNuevoDepartamento.Size = new System.Drawing.Size(184, 21);
            this.lblNuevoDepartamento.TabIndex = 3;
            this.lblNuevoDepartamento.Text = "NUEVO DEPARTAMENTO";
            
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNombre.Location = new System.Drawing.Point(347, 110);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(52, 15);
            this.lblNombre.TabIndex = 4;
            this.lblNombre.Text = "Nombre";
            
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNombre.Location = new System.Drawing.Point(350, 130);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(300, 23);
            this.txtNombre.TabIndex = 5;
            
            this.btnGuardarDepartamento.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnGuardarDepartamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardarDepartamento.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnGuardarDepartamento.Location = new System.Drawing.Point(350, 170);
            this.btnGuardarDepartamento.Name = "btnGuardarDepartamento";
            this.btnGuardarDepartamento.Size = new System.Drawing.Size(170, 28);
            this.btnGuardarDepartamento.TabIndex = 6;
            this.btnGuardarDepartamento.Text = "Guardar Departamento";
            this.btnGuardarDepartamento.UseVisualStyleBackColor = true;
            this.btnGuardarDepartamento.Click += new System.EventHandler(this.btnGuardarDepartamento_Click);
            
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCancelar.Location = new System.Drawing.Point(530, 170);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(120, 28);
            this.btnCancelar.TabIndex = 7;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 450);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardarDepartamento);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblNuevoDepartamento);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnNuevoDepartamento);
            this.Controls.Add(this.dgvDepartamentos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "departamentos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Departamentos";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartamentos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDepartamentos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIdDepartamento;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNombre;
        private System.Windows.Forms.Button btnNuevoDepartamento;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Label lblNuevoDepartamento;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnGuardarDepartamento;
        private System.Windows.Forms.Button btnCancelar;
    }
}
