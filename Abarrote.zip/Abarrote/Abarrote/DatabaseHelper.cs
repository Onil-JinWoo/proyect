using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Abarrote
{
    public class ProductoVentaInfo
    {
        public string CodigoBarras { get; set; }
        public string Descripcion { get; set; }
        public decimal PrecioVenta { get; set; }
        public decimal PrecioMayoreo { get; set; }
        public int StockActual { get; set; }
    }

    public class ProductoInfo
    {
        public int IdProducto { get; set; }
        public string CodigoBarras { get; set; }
        public string Descripcion { get; set; }
        public string TipoVenta { get; set; }
        public decimal PrecioCosto { get; set; }
        public decimal Ganancia { get; set; }
        public decimal PrecioVenta { get; set; }
        public decimal PrecioMayoreo { get; set; }
        public string Departamento { get; set; }
        public bool UsaInventario { get; set; }
        public int StockActual { get; set; }
        public int StockMinimo { get; set; }
        public int StockMaximo { get; set; }
    }

    public class DatabaseHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["AbarroteDB"].ConnectionString;

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public struct CorteResumen
        {
            public decimal VentasEfectivo;
            public decimal Impuestos;
            public decimal SalidasEfectivo;
            public decimal PagosCredito;

            public decimal FondoCaja;
            public decimal EntradasEfectivo;
            public decimal SalidasCaja;

            public List<KeyValuePair<string, decimal>> VentasPorDepartamento;

            public int ClienteMasVentasId;
            public string ClienteMasVentasNombre;
            public decimal ClienteMasVentasTotal;

            public int ClienteMasGananciaId;
            public string ClienteMasGananciaNombre;
            public decimal ClienteMasGananciaTotal;
        }

        public static bool ObtenerResumenCorte(DateTime desde, DateTime hasta, out CorteResumen resumen, out string error)
        {
            resumen = new CorteResumen();
            resumen.VentasPorDepartamento = new List<KeyValuePair<string, decimal>>();
            error = string.Empty;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablasVentas(connection);
                    EnsureTablaCajaMovimientos(connection);

                    string colFecha = ColumnaExiste(connection, "dbo", "Ventas", "FechaVenta") ? "FechaVenta" : (ColumnaExiste(connection, "dbo", "Ventas", "Fecha") ? "Fecha" : "FechaVenta");

                    // Ventas Totales (no tenemos desglose por método de pago; por ahora todo se toma como efectivo)
                    using (SqlCommand cmd = new SqlCommand(
                        string.Format("SELECT ISNULL(SUM(Total),0) FROM dbo.Ventas WHERE {0} >= @Desde AND {0} <= @Hasta", colFecha),
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Desde", desde);
                        cmd.Parameters.AddWithValue("@Hasta", hasta);
                        object r = cmd.ExecuteScalar();
                        resumen.VentasEfectivo = r == null || r == DBNull.Value ? 0m : Convert.ToDecimal(r);
                    }

                    // Movimientos de caja
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT Tipo, ISNULL(SUM(Monto),0) AS Total FROM dbo.CajaMovimientos WHERE Fecha >= @Desde AND Fecha <= @Hasta GROUP BY Tipo",
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Desde", desde);
                        cmd.Parameters.AddWithValue("@Hasta", hasta);
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            while (rd.Read())
                            {
                                string tipo = rd["Tipo"] == DBNull.Value ? string.Empty : rd["Tipo"].ToString();
                                decimal tot = rd["Total"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Total"]);

                                if (string.Equals(tipo, "FONDO", StringComparison.OrdinalIgnoreCase))
                                    resumen.FondoCaja += tot;
                                else if (string.Equals(tipo, "ENTRADA", StringComparison.OrdinalIgnoreCase))
                                    resumen.EntradasEfectivo += tot;
                                else if (string.Equals(tipo, "SALIDA", StringComparison.OrdinalIgnoreCase))
                                    resumen.SalidasCaja += tot;
                                else if (string.Equals(tipo, "PAGO_CREDITO", StringComparison.OrdinalIgnoreCase))
                                    resumen.PagosCredito += tot;
                            }
                        }
                    }

                    // Ventas por Departamento (si existe tabla Productos y columna Departamento)
                    bool productosExiste = TablaExiste(connection, "dbo", "Productos");
                    bool prodTieneDepto = productosExiste && ColumnaExiste(connection, "dbo", "Productos", "Departamento");
                    bool detTieneCodigo = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "CodigoBarras");
                    bool detTieneCantidad = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "Cantidad");
                    bool detTienePrecio = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "PrecioVenta");

                    if (productosExiste && prodTieneDepto && detTieneCodigo && detTieneCantidad && detTienePrecio)
                    {
                        string qDepto = string.Format(
                            @"SELECT ISNULL(p.Departamento,'') AS Departamento,
                                      SUM(d.Cantidad * d.PrecioVenta) AS Total
                               FROM dbo.Ventas v
                               INNER JOIN dbo.VentasDetalle d ON d.IdVenta = v.IdVenta
                               LEFT JOIN dbo.Productos p ON p.CodigoBarras = d.CodigoBarras
                               WHERE v.{0} >= @Desde AND v.{0} <= @Hasta
                               GROUP BY ISNULL(p.Departamento,'')
                               ORDER BY Total DESC", colFecha);

                        using (SqlCommand cmd = new SqlCommand(qDepto, connection))
                        {
                            cmd.Parameters.AddWithValue("@Desde", desde);
                            cmd.Parameters.AddWithValue("@Hasta", hasta);
                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                while (rd.Read())
                                {
                                    string dpto = rd["Departamento"] == DBNull.Value ? string.Empty : rd["Departamento"].ToString();
                                    decimal tot = rd["Total"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Total"]);
                                    if (string.IsNullOrWhiteSpace(dpto))
                                        dpto = "(Sin departamento)";
                                    if (tot > 0m)
                                        resumen.VentasPorDepartamento.Add(new KeyValuePair<string, decimal>(dpto, tot));
                                }
                            }
                        }
                    }

                    // Top clientes por ventas / ganancia (si Ventas tiene IdCliente)
                    bool ventasTieneIdCliente = ColumnaExiste(connection, "dbo", "Ventas", "IdCliente");
                    if (ventasTieneIdCliente)
                    {
                        string qTopVentas = string.Format(
                            "SELECT TOP 1 IdCliente, ISNULL(SUM(Total),0) AS Total FROM dbo.Ventas WHERE IdCliente IS NOT NULL AND {0} >= @Desde AND {0} <= @Hasta GROUP BY IdCliente ORDER BY Total DESC",
                            colFecha);

                        using (SqlCommand cmd = new SqlCommand(qTopVentas, connection))
                        {
                            cmd.Parameters.AddWithValue("@Desde", desde);
                            cmd.Parameters.AddWithValue("@Hasta", hasta);
                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                if (rd.Read())
                                {
                                    resumen.ClienteMasVentasId = rd["IdCliente"] == DBNull.Value ? 0 : Convert.ToInt32(rd["IdCliente"]);
                                    resumen.ClienteMasVentasTotal = rd["Total"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Total"]);
                                }
                            }
                        }

                        if (resumen.ClienteMasVentasId > 0 && TablaExiste(connection, "dbo", "Clientes"))
                        {
                            using (SqlCommand cmd = new SqlCommand(
                                "SELECT TOP 1 (LTRIM(RTRIM(ISNULL(Nombres,''))) + ' ' + LTRIM(RTRIM(ISNULL(Apellidos,'')))) AS Nombre FROM dbo.Clientes WHERE IdCliente=@Id",
                                connection))
                            {
                                cmd.Parameters.AddWithValue("@Id", resumen.ClienteMasVentasId);
                                object r = cmd.ExecuteScalar();
                                resumen.ClienteMasVentasNombre = r == null || r == DBNull.Value ? resumen.ClienteMasVentasId.ToString() : r.ToString();
                            }
                        }

                        // Ganancia: si podemos calcular (PrecioVenta - PrecioCosto)
                        if (productosExiste && ColumnaExiste(connection, "dbo", "Productos", "PrecioCosto") && detTieneCodigo && detTieneCantidad && detTienePrecio)
                        {
                            string qTopGan = string.Format(
                                @"SELECT TOP 1 v.IdCliente,
                                          SUM((d.PrecioVenta - ISNULL(p.PrecioCosto,0)) * d.Cantidad) AS Ganancia
                                   FROM dbo.Ventas v
                                   INNER JOIN dbo.VentasDetalle d ON d.IdVenta = v.IdVenta
                                   LEFT JOIN dbo.Productos p ON p.CodigoBarras = d.CodigoBarras
                                   WHERE v.IdCliente IS NOT NULL AND v.{0} >= @Desde AND v.{0} <= @Hasta
                                   GROUP BY v.IdCliente
                                   ORDER BY Ganancia DESC", colFecha);

                            using (SqlCommand cmd = new SqlCommand(qTopGan, connection))
                            {
                                cmd.Parameters.AddWithValue("@Desde", desde);
                                cmd.Parameters.AddWithValue("@Hasta", hasta);
                                using (SqlDataReader rd = cmd.ExecuteReader())
                                {
                                    if (rd.Read())
                                    {
                                        resumen.ClienteMasGananciaId = rd["IdCliente"] == DBNull.Value ? 0 : Convert.ToInt32(rd["IdCliente"]);
                                        resumen.ClienteMasGananciaTotal = rd["Ganancia"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Ganancia"]);
                                    }
                                }
                            }

                            if (resumen.ClienteMasGananciaId > 0 && TablaExiste(connection, "dbo", "Clientes"))
                            {
                                using (SqlCommand cmd = new SqlCommand(
                                    "SELECT TOP 1 (LTRIM(RTRIM(ISNULL(Nombres,''))) + ' ' + LTRIM(RTRIM(ISNULL(Apellidos,'')))) AS Nombre FROM dbo.Clientes WHERE IdCliente=@Id",
                                    connection))
                                {
                                    cmd.Parameters.AddWithValue("@Id", resumen.ClienteMasGananciaId);
                                    object r = cmd.ExecuteScalar();
                                    resumen.ClienteMasGananciaNombre = r == null || r == DBNull.Value ? resumen.ClienteMasGananciaId.ToString() : r.ToString();
                                }
                            }
                        }
                    }

                    // Impuestos: pendiente
                    resumen.Impuestos = 0m;
                    // Salidas: usar movimientos de caja
                    resumen.SalidasEfectivo = resumen.SalidasCaja;

                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool AgregarInventarioYActualizarPrecios(string codigoBarras, int cantidadAgregar, decimal precioCosto, decimal precioVenta, decimal precioMayoreo, out string error)
        {
            error = string.Empty;
            string cod = (codigoBarras ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(cod))
                return false;
            if (cantidadAgregar <= 0)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    using (SqlTransaction tx = connection.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand cmd = new SqlCommand(
                                @"UPDATE dbo.Productos
                                   SET StockActual = ISNULL(StockActual,0) + @Agregar,
                                       PrecioCosto = @Costo,
                                       PrecioVenta = @Venta,
                                       PrecioMayoreo = @Mayoreo
                                   WHERE CodigoBarras = @Codigo",
                                connection, tx))
                            {
                                cmd.Parameters.AddWithValue("@Agregar", cantidadAgregar);
                                cmd.Parameters.AddWithValue("@Costo", precioCosto);
                                cmd.Parameters.AddWithValue("@Venta", precioVenta);
                                cmd.Parameters.AddWithValue("@Mayoreo", precioMayoreo);
                                cmd.Parameters.AddWithValue("@Codigo", cod);
                                int n = cmd.ExecuteNonQuery();
                                if (n <= 0)
                                {
                                    tx.Rollback();
                                    error = "Producto no encontrado.";
                                    return false;
                                }
                            }

                            tx.Commit();
                            return true;
                        }
                        catch (Exception exTx)
                        {
                            try { tx.Rollback(); } catch { }
                            error = exTx.Message;
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool ObtenerPromocionesVigentes(out DataTable dt, out string error)
        {
            dt = new DataTable();
            error = string.Empty;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "promocion"))
                        return true;

                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT IdPromocion, NombrePromocion, CodigoBarras, CantidadDesde, CantidadHasta, PrecioPromocion, FechaCreacion FROM dbo.promocion WHERE ISNULL(Activa,1)=1 ORDER BY FechaCreacion DESC",
                        connection))
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool CrearPromocion(string nombrePromocion, string codigoBarras, decimal cantidadDesde, decimal cantidadHasta, decimal precioPromocion, out string error)
        {
            error = string.Empty;
            string nom = (nombrePromocion ?? string.Empty).Trim();
            string cod = (codigoBarras ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(nom) || string.IsNullOrWhiteSpace(cod))
                return false;
            if (cantidadDesde < 0m || cantidadHasta <= 0m || cantidadHasta < cantidadDesde)
                return false;
            if (precioPromocion <= 0m)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "promocion"))
                    {
                        error = "No existe la tabla promocion.";
                        return false;
                    }

                    bool idEsIdentity = ColumnaExiste(connection, "dbo", "promocion", "IdPromocion") && ColumnaEsIdentity(connection, "dbo", "promocion", "IdPromocion");

                    using (SqlTransaction tx = connection.BeginTransaction())
                    {
                        try
                        {
                            int nextId = 0;
                            if (!idEsIdentity)
                            {
                                using (SqlCommand cmdNext = new SqlCommand(
                                    "SELECT ISNULL(MAX(IdPromocion),0) + 1 FROM dbo.promocion WITH (UPDLOCK, HOLDLOCK)",
                                    connection, tx))
                                {
                                    object r = cmdNext.ExecuteScalar();
                                    nextId = r == null || r == DBNull.Value ? 1 : Convert.ToInt32(r);
                                    if (nextId <= 0) nextId = 1;
                                }
                            }

                            string q = idEsIdentity
                                ? "INSERT INTO dbo.promocion (NombrePromocion, CodigoBarras, CantidadDesde, CantidadHasta, PrecioPromocion, Activa, FechaCreacion) VALUES (@Nombre, @Codigo, @Desde, @Hasta, @Precio, 1, GETDATE())"
                                : "INSERT INTO dbo.promocion (IdPromocion, NombrePromocion, CodigoBarras, CantidadDesde, CantidadHasta, PrecioPromocion, Activa, FechaCreacion) VALUES (@Id, @Nombre, @Codigo, @Desde, @Hasta, @Precio, 1, GETDATE())";

                            using (SqlCommand cmd = new SqlCommand(q, connection, tx))
                            {
                                if (!idEsIdentity)
                                    cmd.Parameters.AddWithValue("@Id", nextId);

                                cmd.Parameters.AddWithValue("@Nombre", nom);
                                cmd.Parameters.AddWithValue("@Codigo", cod);
                                cmd.Parameters.AddWithValue("@Desde", cantidadDesde);
                                cmd.Parameters.AddWithValue("@Hasta", cantidadHasta);
                                cmd.Parameters.AddWithValue("@Precio", precioPromocion);
                                cmd.ExecuteNonQuery();
                            }

                            tx.Commit();
                            return true;
                        }
                        catch (Exception exTx)
                        {
                            try { tx.Rollback(); } catch { }
                            error = exTx.Message;
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool DesactivarPromocion(int idPromocion, out string error)
        {
            error = string.Empty;
            if (idPromocion <= 0)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "promocion"))
                    {
                        error = "No existe la tabla promocion.";
                        return false;
                    }

                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE dbo.promocion SET Activa=0 WHERE IdPromocion=@Id",
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Id", idPromocion);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool ObtenerVentasPorDia(DateTime desde, DateTime hasta, out List<KeyValuePair<DateTime, decimal>> data, out string error)
        {
            data = new List<KeyValuePair<DateTime, decimal>>();
            error = string.Empty;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablasVentas(connection);

                    string colFecha = ColumnaExiste(connection, "dbo", "Ventas", "FechaVenta") ? "FechaVenta" : (ColumnaExiste(connection, "dbo", "Ventas", "Fecha") ? "Fecha" : "FechaVenta");

                    string q = string.Format(
                        @"SELECT CAST({0} AS date) AS Dia, ISNULL(SUM(Total),0) AS Total
                          FROM dbo.Ventas
                          WHERE {0} >= @Desde AND {0} <= @Hasta
                          GROUP BY CAST({0} AS date)
                          ORDER BY CAST({0} AS date)",
                        colFecha);

                    using (SqlCommand cmd = new SqlCommand(q, connection))
                    {
                        cmd.Parameters.AddWithValue("@Desde", desde);
                        cmd.Parameters.AddWithValue("@Hasta", hasta);
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            while (rd.Read())
                            {
                                DateTime dia = rd["Dia"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(rd["Dia"]);
                                decimal total = rd["Total"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Total"]);
                                if (dia != DateTime.MinValue)
                                    data.Add(new KeyValuePair<DateTime, decimal>(dia, total));
                            }
                        }
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool ObtenerGananciaPorDepartamento(DateTime desde, DateTime hasta, out List<KeyValuePair<string, decimal>> data, out string error)
        {
            data = new List<KeyValuePair<string, decimal>>();
            error = string.Empty;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablasVentas(connection);

                    bool productosExiste = TablaExiste(connection, "dbo", "Productos");
                    bool prodTieneDepto = productosExiste && ColumnaExiste(connection, "dbo", "Productos", "Departamento");
                    bool prodTieneCosto = productosExiste && ColumnaExiste(connection, "dbo", "Productos", "PrecioCosto");
                    bool detTieneCodigo = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "CodigoBarras");
                    bool detTieneCantidad = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "Cantidad");
                    bool detTienePrecio = TablaExiste(connection, "dbo", "VentasDetalle") && ColumnaExiste(connection, "dbo", "VentasDetalle", "PrecioVenta");
                    string colFecha = ColumnaExiste(connection, "dbo", "Ventas", "FechaVenta") ? "FechaVenta" : (ColumnaExiste(connection, "dbo", "Ventas", "Fecha") ? "Fecha" : "FechaVenta");

                    if (!productosExiste || !prodTieneDepto || !detTieneCodigo || !detTieneCantidad || !detTienePrecio)
                        return true;

                    string expr = prodTieneCosto
                        ? "SUM( (ISNULL(d.PrecioVenta,0) - ISNULL(p.PrecioCosto,0)) * ISNULL(d.Cantidad,0) )"
                        : "SUM( ISNULL(d.PrecioVenta,0) * ISNULL(d.Cantidad,0) )";

                    string q = string.Format(
                        @"SELECT ISNULL(NULLIF(LTRIM(RTRIM(p.Departamento)),''),'Sin departamento') AS Depto,
                                 {0} AS Total
                          FROM dbo.Ventas v
                          INNER JOIN dbo.VentasDetalle d ON d.IdVenta = v.IdVenta
                          INNER JOIN dbo.Productos p ON p.CodigoBarras = d.CodigoBarras
                          WHERE v.{1} >= @Desde AND v.{1} <= @Hasta
                          GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(p.Departamento)),''),'Sin departamento')
                          ORDER BY {0} DESC", expr, colFecha);

                    using (SqlCommand cmd = new SqlCommand(q, connection))
                    {
                        cmd.Parameters.AddWithValue("@Desde", desde);
                        cmd.Parameters.AddWithValue("@Hasta", hasta);
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            while (rd.Read())
                            {
                                string depto = rd["Depto"] == DBNull.Value ? "" : rd["Depto"].ToString();
                                decimal total = rd["Total"] == DBNull.Value ? 0m : Convert.ToDecimal(rd["Total"]);
                                if (!string.IsNullOrWhiteSpace(depto))
                                    data.Add(new KeyValuePair<string, decimal>(depto, total));
                            }
                        }
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        private static void EnsureTablasVentas(SqlConnection connection)
        {
            if (connection == null)
                return;

            string query =
                "IF OBJECT_ID('dbo.Ventas','U') IS NULL " +
                "BEGIN " +
                "CREATE TABLE dbo.Ventas(" +
                "IdVenta INT IDENTITY(1,1) NOT NULL PRIMARY KEY," +
                "FechaVenta DATETIME NOT NULL DEFAULT(GETDATE())," +
                "Total DECIMAL(18,2) NOT NULL DEFAULT(0)," +
                "IdCliente INT NULL" +
                ");" +
                "CREATE INDEX IX_Ventas_FechaVenta ON dbo.Ventas(FechaVenta);" +
                "END;" +
                "IF OBJECT_ID('dbo.Ventas','U') IS NOT NULL AND COL_LENGTH('dbo.Ventas','IdCliente') IS NULL " +
                "BEGIN ALTER TABLE dbo.Ventas ADD IdCliente INT NULL; END;" +
                "IF OBJECT_ID('dbo.VentasDetalle','U') IS NULL " +
                "BEGIN " +
                "CREATE TABLE dbo.VentasDetalle(" +
                "IdDetalle INT IDENTITY(1,1) NOT NULL PRIMARY KEY," +
                "IdVenta INT NOT NULL," +
                "CodigoBarras VARCHAR(50) NOT NULL," +
                "Descripcion VARCHAR(200) NOT NULL," +
                "Cantidad DECIMAL(18,2) NOT NULL," +
                "PrecioVenta DECIMAL(18,2) NOT NULL" +
                ");" +
                "CREATE INDEX IX_VentasDetalle_IdVenta ON dbo.VentasDetalle(IdVenta);" +
                "END";

            using (SqlCommand cmd = new SqlCommand(query, connection))
                cmd.ExecuteNonQuery();
        }

        private static void EnsureTablaCajaMovimientos(SqlConnection connection)
        {
            if (connection == null)
                return;

            string q =
                "IF OBJECT_ID('dbo.CajaMovimientos','U') IS NULL " +
                "BEGIN " +
                "CREATE TABLE dbo.CajaMovimientos(" +
                "IdMovimiento INT IDENTITY(1,1) NOT NULL PRIMARY KEY," +
                "Fecha DATETIME NOT NULL DEFAULT(GETDATE())," +
                "Tipo VARCHAR(20) NOT NULL," +
                "Monto DECIMAL(18,2) NOT NULL DEFAULT(0)," +
                "Comentario VARCHAR(200) NULL," +
                "Usuario VARCHAR(50) NULL" +
                ");" +
                "CREATE INDEX IX_CajaMovimientos_Fecha ON dbo.CajaMovimientos(Fecha);" +
                "END";

            using (SqlCommand cmd = new SqlCommand(q, connection))
                cmd.ExecuteNonQuery();
        }

        public static bool RegistrarMovimientoCaja(string tipo, decimal monto, string comentario, string usuario, out string error)
        {
            error = string.Empty;
            string t = (tipo ?? string.Empty).Trim().ToUpperInvariant();
            if (string.IsNullOrWhiteSpace(t))
                return false;
            if (monto <= 0m)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablaCajaMovimientos(connection);

                    using (SqlCommand cmd = new SqlCommand(
                        "INSERT INTO dbo.CajaMovimientos (Fecha, Tipo, Monto, Comentario, Usuario) VALUES (GETDATE(), @Tipo, @Monto, @Comentario, @Usuario)",
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Tipo", t);
                        cmd.Parameters.AddWithValue("@Monto", monto);
                        cmd.Parameters.AddWithValue("@Comentario", string.IsNullOrWhiteSpace(comentario) ? (object)DBNull.Value : comentario.Trim());
                        cmd.Parameters.AddWithValue("@Usuario", string.IsNullOrWhiteSpace(usuario) ? (object)DBNull.Value : usuario.Trim());
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public class VentaDetalleItem
        {
            public string CodigoBarras { get; set; }
            public string Descripcion { get; set; }
            public decimal Cantidad { get; set; }
            public decimal PrecioVenta { get; set; }
        }

        public static bool ProcesarVenta(
            decimal total,
            int idCliente,
            List<VentaDetalleItem> detalle,
            out int idVenta,
            out string error)
        {
            idVenta = 0;
            error = string.Empty;

            if (total <= 0m)
                return false;
            if (detalle == null || detalle.Count == 0)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablasVentas(connection);

                    // IMPORTANTE: No ejecutar comandos fuera de la transacción cuando la conexión ya está enlistada
                    // en una transacción pendiente. Por eso, todas las validaciones de esquema van aquí, ANTES del BeginTransaction.
                    bool productosExiste = TablaExiste(connection, "dbo", "Productos");
                    bool productosTieneStock = productosExiste && ColumnaExiste(connection, "dbo", "Productos", "StockActual");

                    bool ventasTieneIdCliente = ColumnaExiste(connection, "dbo", "Ventas", "IdCliente");
                    string colFecha = ColumnaExiste(connection, "dbo", "Ventas", "FechaVenta") ? "FechaVenta" : (ColumnaExiste(connection, "dbo", "Ventas", "Fecha") ? "Fecha" : "FechaVenta");
                    string colTotal = ColumnaExiste(connection, "dbo", "Ventas", "Total") ? "Total" : "Total";

                    bool detTieneDescripcion = ColumnaExiste(connection, "dbo", "VentasDetalle", "Descripcion");
                    bool detTieneCodigo = ColumnaExiste(connection, "dbo", "VentasDetalle", "CodigoBarras");
                    bool detTieneCantidad = ColumnaExiste(connection, "dbo", "VentasDetalle", "Cantidad");
                    bool detTienePrecio = ColumnaExiste(connection, "dbo", "VentasDetalle", "PrecioVenta");

                    if (!detTieneCodigo || !detTieneCantidad || !detTienePrecio)
                    {
                        error = "La tabla VentasDetalle no tiene las columnas mínimas (CodigoBarras, Cantidad, PrecioVenta).";
                        return false;
                    }

                    using (SqlTransaction tx = connection.BeginTransaction())
                    {
                        try
                        {
                            // 1) Descontar inventario (solo para productos reales con existencia > 0 y no COMUN)
                            for (int i = 0; i < detalle.Count; i++)
                            {
                                VentaDetalleItem it = detalle[i];
                                string codigo = it == null ? string.Empty : (it.CodigoBarras ?? string.Empty).Trim();
                                if (string.IsNullOrWhiteSpace(codigo))
                                    continue;
                                if (codigo.StartsWith("COMUN-", StringComparison.OrdinalIgnoreCase))
                                    continue;

                                // si no existe la tabla Productos o no hay StockActual, saltar inventario
                                if (!productosExiste || !productosTieneStock)
                                    continue;

                                int existencia = 0;
                                using (SqlCommand cmdExist = new SqlCommand("SELECT ISNULL(StockActual,0) FROM dbo.Productos WHERE CodigoBarras=@Codigo", connection, tx))
                                {
                                    cmdExist.Parameters.AddWithValue("@Codigo", codigo);
                                    object r = cmdExist.ExecuteScalar();
                                    existencia = r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                                }

                                if (existencia <= 0)
                                    continue;

                                int cant = (int)Math.Round(it.Cantidad <= 0m ? 0m : it.Cantidad, 0);
                                if (cant <= 0)
                                    continue;

                                using (SqlCommand cmdUpd = new SqlCommand(
                                    "UPDATE dbo.Productos SET StockActual = StockActual - @Cantidad WHERE CodigoBarras=@Codigo AND StockActual >= @Cantidad",
                                    connection, tx))
                                {
                                    cmdUpd.Parameters.AddWithValue("@Cantidad", cant);
                                    cmdUpd.Parameters.AddWithValue("@Codigo", codigo);

                                    int affected = cmdUpd.ExecuteNonQuery();
                                    if (affected <= 0)
                                    {
                                        tx.Rollback();
                                        error = string.Format("Inventario insuficiente o producto no encontrado: {0}", codigo);
                                        return false;
                                    }
                                }
                            }

                            // 2) Insertar venta
                            string qVenta;
                            if (ventasTieneIdCliente)
                            {
                                qVenta = string.Format("INSERT INTO dbo.Ventas ({0}, {1}, IdCliente) VALUES (GETDATE(), @Total, @IdCliente); SELECT CAST(SCOPE_IDENTITY() as int);", colFecha, colTotal);
                            }
                            else
                            {
                                qVenta = string.Format("INSERT INTO dbo.Ventas ({0}, {1}) VALUES (GETDATE(), @Total); SELECT CAST(SCOPE_IDENTITY() as int);", colFecha, colTotal);
                            }

                            using (SqlCommand cmdVenta = new SqlCommand(qVenta, connection, tx))
                            {
                                cmdVenta.Parameters.AddWithValue("@Total", total);
                                if (ventasTieneIdCliente)
                                    cmdVenta.Parameters.AddWithValue("@IdCliente", idCliente > 0 ? (object)idCliente : DBNull.Value);
                                object r = cmdVenta.ExecuteScalar();
                                idVenta = r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                            }

                            if (idVenta <= 0)
                            {
                                tx.Rollback();
                                error = "No se pudo generar IdVenta.";
                                return false;
                            }

                            // 3) Insertar detalle
                            for (int i = 0; i < detalle.Count; i++)
                            {
                                VentaDetalleItem it = detalle[i];
                                if (it == null)
                                    continue;

                                string codigo = (it.CodigoBarras ?? string.Empty).Trim();
                                if (string.IsNullOrWhiteSpace(codigo))
                                    continue;

                                decimal cant = it.Cantidad <= 0m ? 0m : it.Cantidad;
                                if (cant <= 0m)
                                    continue;

                                decimal precio = it.PrecioVenta < 0m ? 0m : it.PrecioVenta;
                                string desc = string.IsNullOrWhiteSpace(it.Descripcion) ? codigo : it.Descripcion.Trim();

                                string qDet = detTieneDescripcion
                                    ? "INSERT INTO dbo.VentasDetalle (IdVenta, CodigoBarras, Descripcion, Cantidad, PrecioVenta) VALUES (@IdVenta, @Codigo, @Descripcion, @Cantidad, @Precio);"
                                    : "INSERT INTO dbo.VentasDetalle (IdVenta, CodigoBarras, Cantidad, PrecioVenta) VALUES (@IdVenta, @Codigo, @Cantidad, @Precio);";

                                using (SqlCommand cmdDet = new SqlCommand(qDet, connection, tx))
                                {
                                    cmdDet.Parameters.AddWithValue("@IdVenta", idVenta);
                                    cmdDet.Parameters.AddWithValue("@Codigo", codigo);
                                    cmdDet.Parameters.AddWithValue("@Cantidad", cant);
                                    cmdDet.Parameters.AddWithValue("@Precio", precio);
                                    if (detTieneDescripcion)
                                        cmdDet.Parameters.AddWithValue("@Descripcion", desc);

                                    cmdDet.ExecuteNonQuery();
                                }
                            }

                            tx.Commit();
                            return true;
                        }
                        catch (Exception exTx)
                        {
                            try { tx.Rollback(); } catch { }
                            error = exTx.Message;
                            idVenta = 0;
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    idVenta = 0;
                    return false;
                }
            }
        }

        private static void EnsureTablaProductosPaqueteDetalle(SqlConnection connection)
        {
            if (connection == null)
                return;

            string query =
                "IF OBJECT_ID('dbo.ProductosPaqueteDetalle','U') IS NULL " +
                "BEGIN " +
                "CREATE TABLE dbo.ProductosPaqueteDetalle (" +
                "IdDetalle INT IDENTITY(1,1) NOT NULL PRIMARY KEY," +
                "IdProductoPaquete INT NOT NULL," +
                "CodigoBarrasItem VARCHAR(60) NOT NULL," +
                "Cantidad INT NOT NULL" +
                ");" +
                "CREATE INDEX IX_ProductosPaqueteDetalle_Paquete ON dbo.ProductosPaqueteDetalle(IdProductoPaquete);" +
                "CREATE UNIQUE INDEX UX_ProductosPaqueteDetalle_PaqueteItem ON dbo.ProductosPaqueteDetalle(IdProductoPaquete, CodigoBarrasItem);" +
                "END";

            using (SqlCommand cmd = new SqlCommand(query, connection))
                cmd.ExecuteNonQuery();
        }

        public static int ObtenerIdProductoPorCodigoBarras(string codigoBarras)
        {
            string c = (codigoBarras ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(c))
                return 0;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "Productos"))
                        return 0;

                    using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 IdProducto FROM dbo.Productos WHERE CodigoBarras = @Codigo", connection))
                    {
                        cmd.Parameters.AddWithValue("@Codigo", c);
                        object r = cmd.ExecuteScalar();
                        return r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                    }
                }
                catch
                {
                    return 0;
                }
            }
        }

        public static DataTable ObtenerContenidoPaquete(int idProductoPaquete)
        {
            DataTable dt = new DataTable();
            if (idProductoPaquete <= 0)
                return dt;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablaProductosPaqueteDetalle(connection);

                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT CodigoBarrasItem, Cantidad FROM dbo.ProductosPaqueteDetalle WHERE IdProductoPaquete = @Id ORDER BY CodigoBarrasItem",
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Id", idProductoPaquete);
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                            adp.Fill(dt);
                    }

                    return dt;
                }
                catch
                {
                    return dt;
                }
            }
        }

        public static bool GuardarContenidoPaquete(int idProductoPaquete, Dictionary<string, int> items, out string error)
        {
            error = string.Empty;
            if (idProductoPaquete <= 0)
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    EnsureTablaProductosPaqueteDetalle(connection);

                    using (SqlTransaction tx = connection.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand cmdDel = new SqlCommand("DELETE FROM dbo.ProductosPaqueteDetalle WHERE IdProductoPaquete = @Id", connection, tx))
                            {
                                cmdDel.Parameters.AddWithValue("@Id", idProductoPaquete);
                                cmdDel.ExecuteNonQuery();
                            }

                            if (items != null)
                            {
                                foreach (KeyValuePair<string, int> kv in items)
                                {
                                    string codigo = (kv.Key ?? string.Empty).Trim();
                                    int cant = kv.Value;
                                    if (string.IsNullOrWhiteSpace(codigo) || cant <= 0)
                                        continue;

                                    using (SqlCommand cmdIns = new SqlCommand(
                                        "INSERT INTO dbo.ProductosPaqueteDetalle (IdProductoPaquete, CodigoBarrasItem, Cantidad) VALUES (@Id, @Codigo, @Cantidad)",
                                        connection, tx))
                                    {
                                        cmdIns.Parameters.AddWithValue("@Id", idProductoPaquete);
                                        cmdIns.Parameters.AddWithValue("@Codigo", codigo);
                                        cmdIns.Parameters.AddWithValue("@Cantidad", cant);
                                        cmdIns.ExecuteNonQuery();
                                    }
                                }
                            }

                            tx.Commit();
                            return true;
                        }
                        catch (Exception exTx)
                        {
                            try { tx.Rollback(); } catch { }
                            error = exTx.Message;
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static bool DescontarInventarioPorVenta(Dictionary<string, int> items, out string error)
        {
            error = string.Empty;

            if (items == null || items.Count == 0)
                return true;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    if (!TablaExiste(connection, "dbo", "Productos"))
                    {
                        error = "No existe la tabla Productos.";
                        return false;
                    }

                    if (!ColumnaExiste(connection, "dbo", "Productos", "StockActual"))
                        return true;

                    using (SqlTransaction tx = connection.BeginTransaction())
                    {
                        try
                        {
                            foreach (KeyValuePair<string, int> kv in items)
                            {
                                string codigo = (kv.Key ?? string.Empty).Trim();
                                int cant = kv.Value;
                                if (string.IsNullOrWhiteSpace(codigo) || cant <= 0)
                                    continue;

                                using (SqlCommand cmd = new SqlCommand(
                                    "UPDATE dbo.Productos SET StockActual = StockActual - @Cantidad WHERE CodigoBarras = @Codigo AND StockActual >= @Cantidad",
                                    connection, tx))
                                {
                                    cmd.Parameters.AddWithValue("@Cantidad", cant);
                                    cmd.Parameters.AddWithValue("@Codigo", codigo);

                                    int affected = cmd.ExecuteNonQuery();
                                    if (affected <= 0)
                                    {
                                        tx.Rollback();
                                        error = string.Format("Inventario insuficiente o producto no encontrado: {0}", codigo);
                                        return false;
                                    }
                                }
                            }

                            tx.Commit();
                            return true;
                        }
                        catch (Exception exTx)
                        {
                            try { tx.Rollback(); } catch { }
                            error = exTx.Message;
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public static ProductoInfo ObtenerProductoPorCodigoBarras(string codigoBarras)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT IdProducto, CodigoBarras, Descripcion, TipoVenta, PrecioCosto, Ganancia, PrecioVenta, PrecioMayoreo, Departamento, UsaInventario, StockActual, StockMinimo, StockMaximo
                                   FROM dbo.Productos
                                   WHERE CodigoBarras = @CodigoBarras";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CodigoBarras", codigoBarras);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                                return null;

                            ProductoInfo p = new ProductoInfo();
                            p.IdProducto = Convert.ToInt32(reader["IdProducto"]);
                            p.CodigoBarras = reader["CodigoBarras"].ToString();
                            p.Descripcion = reader["Descripcion"].ToString();
                            p.TipoVenta = reader["TipoVenta"].ToString();

                            object pc = reader["PrecioCosto"]; p.PrecioCosto = pc == DBNull.Value ? 0m : Convert.ToDecimal(pc);
                            object g = reader["Ganancia"]; p.Ganancia = g == DBNull.Value ? 0m : Convert.ToDecimal(g);
                            object pv = reader["PrecioVenta"]; p.PrecioVenta = pv == DBNull.Value ? 0m : Convert.ToDecimal(pv);
                            object pm = reader["PrecioMayoreo"]; p.PrecioMayoreo = pm == DBNull.Value ? 0m : Convert.ToDecimal(pm);

                            p.Departamento = reader["Departamento"].ToString();

                            object ui = reader["UsaInventario"];
                            p.UsaInventario = ui != DBNull.Value && Convert.ToBoolean(ui);

                            object sa = reader["StockActual"]; p.StockActual = sa == DBNull.Value ? 0 : Convert.ToInt32(sa);
                            object smin = reader["StockMinimo"]; p.StockMinimo = smin == DBNull.Value ? 0 : Convert.ToInt32(smin);
                            object smax = reader["StockMaximo"]; p.StockMaximo = smax == DBNull.Value ? 0 : Convert.ToInt32(smax);

                            return p;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al buscar producto: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return null;
                }
            }
        }

        public static DataRow ObtenerInfoUsuarioInicioSeccion(string usuario, bool mostrarMensajes)
        {
            string u = (usuario ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(u))
                return null;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    DataTable dt = new DataTable();
                    using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 Usuario, Nombre FROM dbo.inicioseccion WHERE Usuario = @Usuario", connection))
                    {
                        cmd.Parameters.AddWithValue("@Usuario", u);
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                            adp.Fill(dt);
                    }

                    if (dt.Rows.Count == 0)
                        return null;

                    return dt.Rows[0];
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener usuario: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return null;
                }
            }
        }

        public static DataTable ObtenerProductosCatalogo(string texto, string departamento, bool mostrarMensajes)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    if (!TablaExiste(connection, "dbo", "Productos"))
                        return dt;

                    string where = " WHERE 1=1 ";

                    if (!string.IsNullOrWhiteSpace(texto))
                        where += " AND (CodigoBarras LIKE @Texto OR Descripcion LIKE @Texto) ";

                    if (!string.IsNullOrWhiteSpace(departamento))
                        where += " AND Departamento = @Departamento ";

                    string query =
                        "SELECT " +
                        "CodigoBarras AS Codigo, " +
                        "Descripcion AS [Descripción del Producto], " +
                        "Departamento, " +
                        "PrecioCosto AS Costo, " +
                        "PrecioVenta AS [P. Venta], " +
                        "PrecioMayoreo AS [P. Mayoreo], " +
                        "StockActual AS Existencia, " +
                        "StockMinimo AS [Inv. Mínimo], " +
                        "StockMaximo AS [Inv. Máximo], " +
                        "TipoVenta AS [Tipo Venta] " +
                        "FROM dbo.Productos" + where +
                        "ORDER BY Descripcion";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrWhiteSpace(texto))
                            cmd.Parameters.AddWithValue("@Texto", "%" + texto + "%");
                        if (!string.IsNullOrWhiteSpace(departamento))
                            cmd.Parameters.AddWithValue("@Departamento", departamento);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener catálogo: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return dt;
                }
            }

            return dt;
        }

        public static DataTable ObtenerClientes(string texto, bool mostrarMensajes)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    if (!TablaExiste(connection, "dbo", "Clientes"))
                        return dt;

                    string where = " WHERE 1=1 ";
                    if (ColumnaExiste(connection, "dbo", "Clientes", "EstadoRegistro"))
                        where += " AND ISNULL(EstadoRegistro, 1) = 1 ";

                    bool tieneTelefono = ColumnaExiste(connection, "dbo", "Clientes", "Telefono");
                    bool tieneCorreo = ColumnaExiste(connection, "dbo", "Clientes", "CorreoElectronico");

                    if (!string.IsNullOrWhiteSpace(texto))
                    {
                        string filtro = "(Nombres LIKE @Texto OR Apellidos LIKE @Texto";
                        if (tieneTelefono)
                            filtro += " OR Telefono LIKE @Texto";
                        if (tieneCorreo)
                            filtro += " OR CorreoElectronico LIKE @Texto";
                        filtro += ")";
                        where += " AND " + filtro + " ";
                    }

                    string query =
                        "SELECT IdCliente, " +
                        "(LTRIM(RTRIM(ISNULL(Nombres,''))) + ' ' + LTRIM(RTRIM(ISNULL(Apellidos,'')))) AS NombreCompleto, " +
                        (tieneTelefono ? "Telefono" : "CAST('' AS varchar(50)) AS Telefono") + ", " +
                        (tieneCorreo ? "CorreoElectronico" : "CAST('' AS varchar(120)) AS CorreoElectronico") + " " +
                        "FROM dbo.Clientes" + where +
                        "ORDER BY IdCliente DESC";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrWhiteSpace(texto))
                            cmd.Parameters.AddWithValue("@Texto", "%" + texto.Trim() + "%");

                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                            adp.Fill(dt);
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener clientes: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return dt;
                }
            }

            return dt;
        }

        public static DataRow ObtenerClientePorId(int idCliente, bool mostrarMensajes)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "Clientes"))
                        return null;

                    string query = "SELECT TOP 1 * FROM dbo.Clientes WHERE IdCliente = @Id";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Id", idCliente);
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adp.Fill(dt);
                            if (dt.Rows.Count == 0)
                                return null;
                            return dt.Rows[0];
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener cliente: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return null;
                }
            }
        }

        public static int GuardarCliente(
            int idCliente,
            string nombres,
            string apellidos,
            string telefono,
            string correoElectronico,
            string domicilio1,
            string domicilio2,
            string colonia,
            string municipio,
            string estado,
            string codigoPostal,
            string notas,
            bool tieneCredito,
            bool mostrarMensajes)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "Clientes"))
                        return 0;

                    bool tieneEstadoRegistro = ColumnaExiste(connection, "dbo", "Clientes", "EstadoRegistro");
                    bool idEsIdentity = ColumnaExiste(connection, "dbo", "Clientes", "IdCliente") && ColumnaEsIdentity(connection, "dbo", "Clientes", "IdCliente");

                    if (idCliente <= 0)
                    {
                        int idInsertado = 0;
                        if (!idEsIdentity)
                        {
                            using (SqlCommand cmdId = new SqlCommand("SELECT ISNULL(MAX(IdCliente),0)+1 FROM dbo.Clientes", connection))
                            {
                                object rId = cmdId.ExecuteScalar();
                                idInsertado = rId == null || rId == DBNull.Value ? 1 : Convert.ToInt32(rId);
                            }
                        }

                        string query =
                            "INSERT INTO dbo.Clientes (" +
                            (idEsIdentity ? string.Empty : "IdCliente,") +
                            "Nombres,Apellidos,Telefono,CorreoElectronico,Domicilio1,Domicilio2,Colonia,Municipio,Estado,CodigoPostal,Notas,TieneCredito" +
                            (tieneEstadoRegistro ? ",EstadoRegistro" : string.Empty) +
                            ") VALUES (" +
                            (idEsIdentity ? string.Empty : "@IdCliente,") +
                            "@Nombres,@Apellidos,@Telefono,@CorreoElectronico,@Domicilio1,@Domicilio2,@Colonia,@Municipio,@Estado,@CodigoPostal,@Notas,@TieneCredito" +
                            (tieneEstadoRegistro ? ",1" : string.Empty) +
                            ");" +
                            (idEsIdentity ? " SELECT CAST(SCOPE_IDENTITY() as int);" : string.Empty);

                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            if (!idEsIdentity)
                                cmd.Parameters.AddWithValue("@IdCliente", idInsertado);

                            cmd.Parameters.AddWithValue("@Nombres", ValorCliente(connection, "Nombres", nombres));
                            cmd.Parameters.AddWithValue("@Apellidos", ValorCliente(connection, "Apellidos", apellidos));
                            cmd.Parameters.AddWithValue("@Telefono", ValorCliente(connection, "Telefono", telefono));
                            cmd.Parameters.AddWithValue("@CorreoElectronico", ValorCliente(connection, "CorreoElectronico", correoElectronico));
                            cmd.Parameters.AddWithValue("@Domicilio1", ValorCliente(connection, "Domicilio1", domicilio1));
                            cmd.Parameters.AddWithValue("@Domicilio2", ValorCliente(connection, "Domicilio2", domicilio2));
                            cmd.Parameters.AddWithValue("@Colonia", ValorCliente(connection, "Colonia", colonia));
                            cmd.Parameters.AddWithValue("@Municipio", ValorCliente(connection, "Municipio", municipio));
                            cmd.Parameters.AddWithValue("@Estado", ValorCliente(connection, "Estado", estado));
                            cmd.Parameters.AddWithValue("@CodigoPostal", ValorCliente(connection, "CodigoPostal", codigoPostal));
                            cmd.Parameters.AddWithValue("@Notas", ValorCliente(connection, "Notas", notas));
                            cmd.Parameters.AddWithValue("@TieneCredito", tieneCredito);

                            if (idEsIdentity)
                            {
                                object r = cmd.ExecuteScalar();
                                return r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                            }

                            cmd.ExecuteNonQuery();
                            return idInsertado;
                        }
                    }
                    else
                    {
                        string query =
                            "UPDATE dbo.Clientes SET " +
                            "Nombres=@Nombres,Apellidos=@Apellidos,Telefono=@Telefono,CorreoElectronico=@CorreoElectronico," +
                            "Domicilio1=@Domicilio1,Domicilio2=@Domicilio2,Colonia=@Colonia,Municipio=@Municipio,Estado=@Estado," +
                            "CodigoPostal=@CodigoPostal,Notas=@Notas,TieneCredito=@TieneCredito" +
                            (tieneEstadoRegistro ? ",EstadoRegistro=1" : string.Empty) +
                            " WHERE IdCliente=@Id";

                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@Id", idCliente);
                            cmd.Parameters.AddWithValue("@Nombres", ValorCliente(connection, "Nombres", nombres));
                            cmd.Parameters.AddWithValue("@Apellidos", ValorCliente(connection, "Apellidos", apellidos));
                            cmd.Parameters.AddWithValue("@Telefono", ValorCliente(connection, "Telefono", telefono));
                            cmd.Parameters.AddWithValue("@CorreoElectronico", ValorCliente(connection, "CorreoElectronico", correoElectronico));
                            cmd.Parameters.AddWithValue("@Domicilio1", ValorCliente(connection, "Domicilio1", domicilio1));
                            cmd.Parameters.AddWithValue("@Domicilio2", ValorCliente(connection, "Domicilio2", domicilio2));
                            cmd.Parameters.AddWithValue("@Colonia", ValorCliente(connection, "Colonia", colonia));
                            cmd.Parameters.AddWithValue("@Municipio", ValorCliente(connection, "Municipio", municipio));
                            cmd.Parameters.AddWithValue("@Estado", ValorCliente(connection, "Estado", estado));
                            cmd.Parameters.AddWithValue("@CodigoPostal", ValorCliente(connection, "CodigoPostal", codigoPostal));
                            cmd.Parameters.AddWithValue("@Notas", ValorCliente(connection, "Notas", notas));
                            cmd.Parameters.AddWithValue("@TieneCredito", tieneCredito);

                            cmd.ExecuteNonQuery();
                            return idCliente;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al guardar cliente: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return 0;
                }
            }
        }

        public static bool EliminarCliente(int idCliente, bool mostrarMensajes)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    if (!TablaExiste(connection, "dbo", "Clientes"))
                        return false;

                    if (ColumnaExiste(connection, "dbo", "Clientes", "EstadoRegistro"))
                    {
                        string query = "UPDATE dbo.Clientes SET EstadoRegistro = 0 WHERE IdCliente = @Id";
                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@Id", idCliente);
                            return cmd.ExecuteNonQuery() > 0;
                        }
                    }
                    else
                    {
                        string query = "DELETE FROM dbo.Clientes WHERE IdCliente = @Id";
                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@Id", idCliente);
                            return cmd.ExecuteNonQuery() > 0;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al eliminar cliente: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return false;
                }
            }
        }

        public static DataTable ObtenerReporteProductosVendidos(DateTime desde, DateTime hasta, bool mostrarMensajes, out decimal totalVendido)
        {
            totalVendido = 0m;

            DataTable dtVacio = new DataTable();
            dtVacio.Columns.Add("Producto", typeof(string));
            dtVacio.Columns.Add("Cantidad", typeof(decimal));
            dtVacio.Columns.Add("PrecioVenta", typeof(decimal));
            dtVacio.Columns.Add("Departamento", typeof(string));

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    if (!TablaExiste(connection, "dbo", "Ventas") || !TablaExiste(connection, "dbo", "VentasDetalle"))
                    {
                        if (mostrarMensajes)
                        {
                            string script =
                                "USE abarrote;\n" +
                                "\n" +
                                "-- TABLA ENCABEZADO\n" +
                                "CREATE TABLE dbo.Ventas(\n" +
                                "    IdVenta INT IDENTITY(1,1) NOT NULL PRIMARY KEY,\n" +
                                "    FechaVenta DATETIME NOT NULL DEFAULT(GETDATE()),\n" +
                                "    Total DECIMAL(18,2) NOT NULL DEFAULT(0)\n" +
                                ");\n" +
                                "\n" +
                                "-- TABLA DETALLE\n" +
                                "CREATE TABLE dbo.VentasDetalle(\n" +
                                "    IdDetalle INT IDENTITY(1,1) NOT NULL PRIMARY KEY,\n" +
                                "    IdVenta INT NOT NULL,\n" +
                                "    CodigoBarras VARCHAR(50) NOT NULL,\n" +
                                "    Descripcion VARCHAR(200) NOT NULL,\n" +
                                "    Cantidad DECIMAL(18,2) NOT NULL,\n" +
                                "    PrecioVenta DECIMAL(18,2) NOT NULL,\n" +
                                "    CONSTRAINT FK_VentasDetalle_Ventas FOREIGN KEY (IdVenta) REFERENCES dbo.Ventas(IdVenta)\n" +
                                ");\n" +
                                "\n" +
                                "-- (Opcional) index para fechas\n" +
                                "CREATE INDEX IX_Ventas_FechaVenta ON dbo.Ventas(FechaVenta);\n";

                            System.Windows.Forms.MessageBox.Show(
                                "No existen las tablas de ventas (dbo.Ventas / dbo.VentasDetalle).\n\n" +
                                "Para poder consultar ventas por periodo, crea las tablas con este SQL en SSMS:\n\n" + script,
                                "Faltan tablas de Ventas",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Warning);
                        }

                        return dtVacio;
                    }

                    string colFecha = ColumnaExiste(connection, "dbo", "Ventas", "FechaVenta") ? "FechaVenta" : (ColumnaExiste(connection, "dbo", "Ventas", "Fecha") ? "Fecha" : "FechaVenta");

                    bool detTieneDescripcion = ColumnaExiste(connection, "dbo", "VentasDetalle", "Descripcion");
                    bool detTieneCodigo = ColumnaExiste(connection, "dbo", "VentasDetalle", "CodigoBarras");
                    bool detTieneCantidad = ColumnaExiste(connection, "dbo", "VentasDetalle", "Cantidad");
                    bool detTienePrecio = ColumnaExiste(connection, "dbo", "VentasDetalle", "PrecioVenta");

                    if (!detTieneCantidad || !detTienePrecio)
                    {
                        if (mostrarMensajes)
                        {
                            System.Windows.Forms.MessageBox.Show(
                                "La tabla dbo.VentasDetalle no tiene las columnas mínimas 'Cantidad' y 'PrecioVenta'.\n" +
                                "Ajusta el esquema para generar el reporte.",
                                "Esquema inválido",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                        return dtVacio;
                    }

                    // Intentar obtener Departamento desde Productos si existe CodigoBarras en detalle
                    bool productosExiste = TablaExiste(connection, "dbo", "Productos");
                    bool prodTieneDepto = productosExiste && ColumnaExiste(connection, "dbo", "Productos", "Departamento");

                    string productoExpr = detTieneDescripcion ? "d.Descripcion" : "''";
                    string deptoExpr = "''";
                    string joinProd = "";

                    if (detTieneCodigo && productosExiste)
                    {
                        joinProd = " LEFT JOIN dbo.Productos p ON p.CodigoBarras = d.CodigoBarras ";
                        if (prodTieneDepto)
                            deptoExpr = "ISNULL(p.Departamento, '')";
                    }

                    string query = string.Format(
                        @"SELECT {0} AS Producto,
                                 SUM(d.Cantidad) AS Cantidad,
                                 AVG(d.PrecioVenta) AS PrecioVenta,
                                 {1} AS Departamento
                          FROM dbo.Ventas v
                          INNER JOIN dbo.VentasDetalle d ON d.IdVenta = v.IdVenta
                          {2}
                          WHERE v.{3} >= @Desde AND v.{3} < DATEADD(day, 1, @Hasta)
                          GROUP BY {0}, {1}
                          ORDER BY {0}",
                        productoExpr,
                        deptoExpr,
                        joinProd,
                        colFecha);

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Desde", desde.Date);
                        cmd.Parameters.AddWithValue("@Hasta", hasta.Date);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            decimal total = 0m;
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                decimal cant = 0m;
                                decimal precio = 0m;

                                object c = dt.Rows[i]["Cantidad"]; if (c != null && c != DBNull.Value) cant = Convert.ToDecimal(c);
                                object p = dt.Rows[i]["PrecioVenta"]; if (p != null && p != DBNull.Value) precio = Convert.ToDecimal(p);
                                total += cant * precio;
                            }
                            totalVendido = total;
                            return dt;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener ventas por periodo: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return dtVacio;
                }
            }
        }

        public static bool ActualizarProducto(int idProducto, string descripcion, string codigoBarras, string tipoVenta, decimal precioCosto, decimal ganancia, decimal precioVenta, decimal precioMayoreo, string departamento, bool usaInventario, int stockActual, int stockMinimo, int stockMaximo)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"UPDATE dbo.Productos
                                   SET CodigoBarras = @CodigoBarras,
                                       Descripcion = @Descripcion,
                                       TipoVenta = @TipoVenta,
                                       PrecioCosto = @PrecioCosto,
                                       Ganancia = @Ganancia,
                                       PrecioVenta = @PrecioVenta,
                                       PrecioMayoreo = @PrecioMayoreo,
                                       Departamento = @Departamento,
                                       UsaInventario = @UsaInventario,
                                       StockActual = @StockActual,
                                       StockMinimo = @StockMinimo,
                                       StockMaximo = @StockMaximo
                                   WHERE IdProducto = @IdProducto";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@IdProducto", idProducto);
                        command.Parameters.AddWithValue("@CodigoBarras", codigoBarras);
                        command.Parameters.AddWithValue("@Descripcion", descripcion);
                        command.Parameters.AddWithValue("@TipoVenta", tipoVenta);
                        command.Parameters.AddWithValue("@PrecioCosto", precioCosto);
                        command.Parameters.AddWithValue("@Ganancia", ganancia);
                        command.Parameters.AddWithValue("@PrecioVenta", precioVenta);
                        command.Parameters.AddWithValue("@PrecioMayoreo", precioMayoreo);
                        command.Parameters.AddWithValue("@Departamento", departamento);
                        command.Parameters.AddWithValue("@UsaInventario", usaInventario);
                        command.Parameters.AddWithValue("@StockActual", stockActual);
                        command.Parameters.AddWithValue("@StockMinimo", stockMinimo);
                        command.Parameters.AddWithValue("@StockMaximo", stockMaximo);
                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al actualizar producto: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static bool EliminarProductoPorIdProducto(int idProducto)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM dbo.Productos WHERE IdProducto = @IdProducto";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@IdProducto", idProducto);
                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al eliminar producto: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        private static bool TablaExiste(SqlConnection connection, string schema, string table)
        {
            string query = @"SELECT COUNT(1)
                             FROM INFORMATION_SCHEMA.TABLES
                             WHERE TABLE_SCHEMA = @Schema AND TABLE_NAME = @Table";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Schema", schema);
                command.Parameters.AddWithValue("@Table", table);
                object result = command.ExecuteScalar();
                int count = result == null ? 0 : Convert.ToInt32(result);
                return count > 0;
            }
        }

        private static bool ColumnaExiste(SqlConnection connection, string schema, string table, string column)
        {
            string query = @"SELECT COUNT(1)
                             FROM INFORMATION_SCHEMA.COLUMNS
                             WHERE TABLE_SCHEMA = @Schema AND TABLE_NAME = @Table AND COLUMN_NAME = @Column";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Schema", schema);
                command.Parameters.AddWithValue("@Table", table);
                command.Parameters.AddWithValue("@Column", column);
                object result = command.ExecuteScalar();
                int count = result == null ? 0 : Convert.ToInt32(result);
                return count > 0;
            }
        }

        private static bool ColumnaPermiteNull(SqlConnection connection, string schema, string table, string column)
        {
            string query = @"SELECT IS_NULLABLE
                             FROM INFORMATION_SCHEMA.COLUMNS
                             WHERE TABLE_SCHEMA = @Schema AND TABLE_NAME = @Table AND COLUMN_NAME = @Column";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Schema", schema);
                command.Parameters.AddWithValue("@Table", table);
                command.Parameters.AddWithValue("@Column", column);
                object result = command.ExecuteScalar();
                string v = result == null || result == DBNull.Value ? string.Empty : result.ToString();
                return string.Equals(v, "YES", StringComparison.OrdinalIgnoreCase);
            }
        }

        private static object ValorCliente(SqlConnection connection, string columnName, string value)
        {
            // Si el usuario deja vacío, enviamos NULL solo si la columna lo permite.
            // Si NO lo permite (NOT NULL), enviamos string vacío para evitar el error.
            if (string.IsNullOrWhiteSpace(value))
            {
                bool permiteNull = ColumnaPermiteNull(connection, "dbo", "Clientes", columnName);
                return permiteNull ? (object)DBNull.Value : string.Empty;
            }

            return value.Trim();
        }

        private static object ToDbNull(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? (object)DBNull.Value : value.Trim();
        }

        private static string ObtenerNombreColumnaDepartamento(SqlConnection connection)
        {
            if (ColumnaExiste(connection, "dbo", "Departamentos", "NombreDepartamento"))
                return "NombreDepartamento";
            if (ColumnaExiste(connection, "dbo", "Departamentos", "Nombre"))
                return "Nombre";
            return "Nombre";
        }

        private static bool ColumnaEsIdentity(SqlConnection connection, string schema, string table, string column)
        {
            string query = string.Format(
                "SELECT COLUMNPROPERTY(OBJECT_ID('{0}.{1}'), '{2}', 'IsIdentity')",
                schema, table, column);

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                object result = command.ExecuteScalar();
                int v = result == null || result == DBNull.Value ? 0 : Convert.ToInt32(result);
                return v == 1;
            }
        }

        public static bool GuardarProducto(string descripcion, string codigoBarras, string tipoVenta, decimal precioCosto, decimal ganancia, decimal precioVenta, decimal precioMayoreo, string departamento, bool usaInventario, int stockActual, int stockMinimo, int stockMaximo)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"INSERT INTO dbo.Productos (IdProducto, CodigoBarras, Descripcion, TipoVenta, PrecioCosto, Ganancia, PrecioVenta, PrecioMayoreo, Departamento, UsaInventario, StockActual, StockMinimo, StockMaximo)
                                   VALUES ((SELECT ISNULL(MAX(IdProducto), 0) + 1 FROM dbo.Productos), @CodigoBarras, @Descripcion, @TipoVenta, @PrecioCosto, @Ganancia, @PrecioVenta, @PrecioMayoreo, @Departamento, @UsaInventario, @StockActual, @StockMinimo, @StockMaximo)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CodigoBarras", codigoBarras);
                        command.Parameters.AddWithValue("@Descripcion", descripcion);
                        command.Parameters.AddWithValue("@TipoVenta", tipoVenta);
                        command.Parameters.AddWithValue("@PrecioCosto", precioCosto);
                        command.Parameters.AddWithValue("@Ganancia", ganancia);
                        command.Parameters.AddWithValue("@PrecioVenta", precioVenta);
                        command.Parameters.AddWithValue("@PrecioMayoreo", precioMayoreo);
                        command.Parameters.AddWithValue("@Departamento", departamento);
                        command.Parameters.AddWithValue("@UsaInventario", usaInventario);
                        command.Parameters.AddWithValue("@StockActual", stockActual);
                        command.Parameters.AddWithValue("@StockMinimo", stockMinimo);
                        command.Parameters.AddWithValue("@StockMaximo", stockMaximo);

                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    string errorMessage = ex.Message;
                    
                    // Manejar errores específicos de base de datos
                    if (errorMessage.Contains("Cannot insert the value NULL into column"))
                    {
                        string columna = "(desconocido)";
                        int i = errorMessage.IndexOf("column '");
                        if (i >= 0)
                        {
                            i += "column '".Length;
                            int j = errorMessage.IndexOf("'", i);
                            if (j > i)
                                columna = errorMessage.Substring(i, j - i);
                        }

                        errorMessage = string.Format("Error: El campo '{0}' no puede estar vacío. Verifica el dato e intenta de nuevo.", columna);
                    }
                    else if (errorMessage.Contains("Cannot insert duplicate key"))
                    {
                        errorMessage = "Error: Ya existe un producto con ese nombre o código de barras.";
                    }
                    else if (errorMessage.Contains("Conversion failed"))
                    {
                        errorMessage = "Error: Verifique que los campos numéricos (precios, cantidades) tengan valores válidos.";
                    }
                    
                    System.Windows.Forms.MessageBox.Show(errorMessage, "Error", 
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static DataTable ObtenerDepartamentos(bool mostrarMensajes)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    if (!TablaExiste(connection, "dbo", "Departamentos"))
                    {
                        if (mostrarMensajes)
                        {
                            string script = "USE abarrote;\n" +
                                            "CREATE TABLE dbo.Departamentos (\n" +
                                            "    IdDepartamento INT IDENTITY(1,1) NOT NULL PRIMARY KEY,\n" +
                                            "    NombreDepartamento VARCHAR(100) NOT NULL\n" +
                                            ");\n" +
                                            "CREATE UNIQUE INDEX UX_Departamentos_NombreDepartamento ON dbo.Departamentos(NombreDepartamento);\n" +
                                            "INSERT INTO dbo.Departamentos (NombreDepartamento) VALUES ('- Sin Departamento -');";

                            System.Windows.Forms.MessageBox.Show(
                                "No existe la tabla dbo.Departamentos en la base de datos 'abarrote'.\n\n" +
                                "Crea la tabla ejecutando este SQL en SSMS:\n\n" + script,
                                "Falta tabla Departamentos",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Warning);
                        }

                        return null;
                    }

                    string colNombre = ObtenerNombreColumnaDepartamento(connection);
                    string query = string.Format(
                        "SELECT IdDepartamento, {0} AS Nombre FROM dbo.Departamentos ORDER BY {0}",
                        colNombre);

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            return dt;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener departamentos: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return null;
                }
            }
        }

        public static DataTable ObtenerDepartamentos()
        {
            return ObtenerDepartamentos(true);
        }

        public static bool InsertarDepartamento(string nombre)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string colNombre = ObtenerNombreColumnaDepartamento(connection);

                    bool idEsIdentity = ColumnaEsIdentity(connection, "dbo", "Departamentos", "IdDepartamento");
                    string query;

                    if (idEsIdentity)
                    {
                        query = string.Format("INSERT INTO dbo.Departamentos ({0}) VALUES (@Nombre)", colNombre);
                    }
                    else
                    {
                        query = string.Format(
                            "INSERT INTO dbo.Departamentos (IdDepartamento, {0}) VALUES ((SELECT ISNULL(MAX(IdDepartamento), 0) + 1 FROM dbo.Departamentos), @Nombre)",
                            colNombre);
                    }

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Nombre", nombre);
                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al guardar departamento: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static bool EliminarDepartamento(int idDepartamento)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM dbo.Departamentos WHERE IdDepartamento = @IdDepartamento";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@IdDepartamento", idDepartamento);
                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al eliminar departamento: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static ProductoVentaInfo ObtenerProductoVentaPorCodigoBarras(string codigoBarras)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT CodigoBarras, Descripcion, PrecioVenta, ISNULL(PrecioMayoreo, PrecioVenta) AS PrecioMayoreo, StockActual
                                   FROM dbo.Productos
                                   WHERE CodigoBarras = @CodigoBarras";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CodigoBarras", codigoBarras);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                                return null;

                            ProductoVentaInfo info = new ProductoVentaInfo();
                            info.CodigoBarras = reader["CodigoBarras"].ToString();
                            info.Descripcion = reader["Descripcion"].ToString();

                            object pv = reader["PrecioVenta"];
                            info.PrecioVenta = pv == DBNull.Value ? 0m : Convert.ToDecimal(pv);

                            object pm = reader["PrecioMayoreo"];
                            info.PrecioMayoreo = pm == DBNull.Value ? info.PrecioVenta : Convert.ToDecimal(pm);

                            object sa = reader["StockActual"];
                            info.StockActual = sa == DBNull.Value ? 0 : Convert.ToInt32(sa);

                            return info;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al buscar producto: {0}", ex.Message), "Error",
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return null;
                }
            }
        }

        public static DataTable ObtenerProductos()
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM dbo.Productos ORDER BY IdProducto";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            return dt;
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener productos: {0}", ex.Message), "Error", 
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return null;
                }
            }
        }

        public static bool ActualizarProducto(int id, string nombre, string descripcion, decimal precio, int existencia, string categoria)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"UPDATE dbo.Productos 
                                   SET Nombre = @Nombre, Descripcion = @Descripcion, Precio = @Precio, 
                                       Existencia = @Existencia, Categoria = @Categoria, FechaActualizacion = GETDATE()
                                   WHERE Id = @Id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Nombre", nombre);
                        command.Parameters.AddWithValue("@Descripcion", descripcion);
                        command.Parameters.AddWithValue("@Precio", precio);
                        command.Parameters.AddWithValue("@Existencia", existencia);
                        command.Parameters.AddWithValue("@Categoria", categoria);

                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al actualizar producto: {0}", ex.Message), "Error", 
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static bool EliminarProducto(int id)
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM dbo.Productos WHERE Id = @Id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        int result = command.ExecuteNonQuery();
                        return result > 0;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(string.Format("Error al eliminar producto: {0}", ex.Message), "Error", 
                        System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return false;
                }
            }
        }

        public static DataTable ObtenerUsuariosInicioSeccion(bool soloActivos, bool mostrarMensajes)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    string where = soloActivos ? " WHERE ISNULL(Activo, 1) = 1 " : string.Empty;
                    string query = "SELECT IdUsuario, Usuario, Nombre, Rol, Activo FROM dbo.inicioseccion" + where + " ORDER BY Usuario";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                        adp.Fill(dt);

                    return dt;
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al obtener usuarios: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return dt;
                }
            }
        }

        public static bool ValidarLoginInicioSeccion(string usuario, string contrasena, bool mostrarMensajes)
        {
            string u = (usuario ?? string.Empty).Trim();
            string p = (contrasena ?? string.Empty);
            if (string.IsNullOrWhiteSpace(u) || string.IsNullOrWhiteSpace(p))
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT TOP 1 IdUsuario FROM dbo.inicioseccion WHERE Usuario = @Usuario AND Contrasena = @Contrasena AND ISNULL(Activo, 1) = 1";

                    int idUsuario = 0;
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@Usuario", u);
                        cmd.Parameters.AddWithValue("@Contrasena", p);

                        object r = cmd.ExecuteScalar();
                        idUsuario = r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                    }

                    if (idUsuario > 0)
                    {
                        try
                        {
                            using (SqlCommand cmd2 = new SqlCommand("UPDATE dbo.inicioseccion SET UltimoAcceso = GETDATE() WHERE IdUsuario = @Id", connection))
                            {
                                cmd2.Parameters.AddWithValue("@Id", idUsuario);
                                cmd2.ExecuteNonQuery();
                            }
                        }
                        catch
                        {
                        }
                        return true;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al validar acceso: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return false;
                }
            }
        }

        public static bool CrearUsuarioInicioSeccion(string usuario, string nombre, string contrasena, string rol, bool mostrarMensajes)
        {
            string u = (usuario ?? string.Empty).Trim();
            string n = (nombre ?? string.Empty).Trim();
            string p = (contrasena ?? string.Empty);
            string r = string.IsNullOrWhiteSpace(rol) ? "Cajero" : rol.Trim();

            if (string.IsNullOrWhiteSpace(u) || string.IsNullOrWhiteSpace(p))
                return false;

            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open();

                    bool idEsIdentity = ColumnaExiste(connection, "dbo", "inicioseccion", "IdUsuario") && ColumnaEsIdentity(connection, "dbo", "inicioseccion", "IdUsuario");
                    bool nombrePermiteNull = ColumnaExiste(connection, "dbo", "inicioseccion", "Nombre") && ColumnaPermiteNull(connection, "dbo", "inicioseccion", "Nombre");

                    int idNuevo = 0;
                    if (!idEsIdentity)
                    {
                        using (SqlCommand cmdId = new SqlCommand("SELECT ISNULL(MAX(IdUsuario), 0) + 1 FROM dbo.inicioseccion", connection))
                        {
                            object rId = cmdId.ExecuteScalar();
                            idNuevo = rId == null || rId == DBNull.Value ? 1 : Convert.ToInt32(rId);
                        }
                    }

                    using (SqlCommand cmdDup = new SqlCommand("SELECT COUNT(1) FROM dbo.inicioseccion WHERE Usuario = @Usuario", connection))
                    {
                        cmdDup.Parameters.AddWithValue("@Usuario", u);
                        int existe = Convert.ToInt32(cmdDup.ExecuteScalar());
                        if (existe > 0)
                        {
                            if (mostrarMensajes)
                            {
                                System.Windows.Forms.MessageBox.Show("Ese usuario ya existe. Elige otro.", "Validación",
                                    System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                            }
                            return false;
                        }
                    }

                    string query;
                    if (idEsIdentity)
                    {
                        query =
                            "INSERT INTO dbo.inicioseccion (Usuario, Nombre, Contrasena, Activo, Rol, FechaCreacion, UltimoAcceso) " +
                            "VALUES (@Usuario, @Nombre, @Contrasena, 1, @Rol, GETDATE(), GETDATE())";
                    }
                    else
                    {
                        query =
                            "INSERT INTO dbo.inicioseccion (IdUsuario, Usuario, Nombre, Contrasena, Activo, Rol, FechaCreacion, UltimoAcceso) " +
                            "VALUES (@IdUsuario, @Usuario, @Nombre, @Contrasena, 1, @Rol, GETDATE(), GETDATE())";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!idEsIdentity)
                            cmd.Parameters.AddWithValue("@IdUsuario", idNuevo);
                        cmd.Parameters.AddWithValue("@Usuario", u);
                        if (string.IsNullOrWhiteSpace(n))
                            cmd.Parameters.AddWithValue("@Nombre", nombrePermiteNull ? (object)DBNull.Value : string.Empty);
                        else
                            cmd.Parameters.AddWithValue("@Nombre", n);
                        cmd.Parameters.AddWithValue("@Contrasena", p);
                        cmd.Parameters.AddWithValue("@Rol", r);
                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
                catch (Exception ex)
                {
                    if (mostrarMensajes)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Error al crear usuario: {0}", ex.Message), "Error",
                            System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    }
                    return false;
                }
            }
        }
    }
}
