﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class corte : UserControl
    {
        public corte()
        {
            InitializeComponent();

            if (btnCorteCajero != null)
                btnCorteCajero.Click += btnCorteCajero_Click;
            if (btnCorteDia != null)
                btnCorteDia.Click += btnCorteDia_Click;
        }

        private void btnCorteCajero_Click(object sender, EventArgs e)
        {
            // Por ahora el corte de cajero = corte del día (ventas de hoy)
            CargarCorte(DateTime.Today, DateTime.Now);
        }

        private void btnCorteDia_Click(object sender, EventArgs e)
        {
            CargarCorte(DateTime.Today, DateTime.Now);
        }

        private void CargarCorte(DateTime desde, DateTime hasta)
        {
            DatabaseHelper.CorteResumen r;
            string err;
            if (!DatabaseHelper.ObtenerResumenCorte(desde, hasta, out r, out err))
            {
                MessageBox.Show(string.Format("No se pudo obtener corte: {0}", err), "Corte", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (lblEntradasEfectivoValor != null)
                lblEntradasEfectivoValor.Text = string.Format("Fondo: {0} | Entradas: {1}", r.FondoCaja.ToString("C2"), r.EntradasEfectivo.ToString("C2"));

            if (lblVentasDepartamentoValor != null)
            {
                if (r.VentasPorDepartamento != null && r.VentasPorDepartamento.Count > 0)
                {
                    // Mostrar el departamento top
                    string top = r.VentasPorDepartamento[0].Key;
                    decimal val = r.VentasPorDepartamento[0].Value;
                    lblVentasDepartamentoValor.Text = string.Format("{0}: {1}", top, val.ToString("C2"));
                }
                else
                {
                    lblVentasDepartamentoValor.Text = "No se registró ninguna venta";
                }
            }

            if (lblImpuestosValor != null)
                lblImpuestosValor.Text = string.Format("Impuestos: {0}", r.Impuestos.ToString("C2"));

            if (lblIngresosContadoValor != null)
                lblIngresosContadoValor.Text = string.Format("Ventas en Efectivo {0}", r.VentasEfectivo.ToString("C2"));

            if (lblSalidasEfectivoValor != null)
                lblSalidasEfectivoValor.Text = string.Format("Salidas: {0}", r.SalidasCaja.ToString("C2"));

            if (lblPagosCreditosValor != null)
                lblPagosCreditosValor.Text = string.Format("Pagos de crédito: {0}", r.PagosCredito.ToString("C2"));

            if (lblClientesMasVentasValor != null)
            {
                if (r.ClienteMasVentasId > 0)
                    lblClientesMasVentasValor.Text = string.Format("{0} - {1}", r.ClienteMasVentasNombre, r.ClienteMasVentasTotal.ToString("C2"));
                else
                    lblClientesMasVentasValor.Text = "No hubo ventas";
            }

            if (lblClientesMasGananciaValor != null)
            {
                if (r.ClienteMasGananciaId > 0)
                    lblClientesMasGananciaValor.Text = string.Format("{0} - {1}", r.ClienteMasGananciaNombre, r.ClienteMasGananciaTotal.ToString("C2"));
                else
                    lblClientesMasGananciaValor.Text = "No hubo ventas";
            }
        }
    }
}
