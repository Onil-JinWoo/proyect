namespace Abarrote
{
    public static class UserSessionState
    {
        public static string Usuario { get; set; }
        public static string Nombre { get; set; }

        public static string NombreParaMostrar
        {
            get
            {
                string n = (Nombre ?? string.Empty).Trim();
                if (!string.IsNullOrWhiteSpace(n))
                    return n;

                return (Usuario ?? string.Empty).Trim();
            }
        }
    }
}
