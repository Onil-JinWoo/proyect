namespace Abarrote
{
    partial class factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.tabControlEncabezado = new System.Windows.Forms.TabControl();
            this.tabPageFacturasVentas = new System.Windows.Forms.TabPage();
            this.tabPageFacturasGlobales = new System.Windows.Forms.TabPage();
            this.tabPageClientesFacturacion = new System.Windows.Forms.TabPage();
            this.labelTitulo = new System.Windows.Forms.Label();
            this.panelFiltros = new System.Windows.Forms.Panel();
            this.comboPeriodo = new System.Windows.Forms.ComboBox();
            this.labelMostrarFacturas = new System.Windows.Forms.Label();
            this.panelCentral = new System.Windows.Forms.Panel();
            this.gridFacturas = new System.Windows.Forms.DataGridView();
            this.colFecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSerie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFolio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImpuestos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFolioVenta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelInferior = new System.Windows.Forms.Panel();
            this.panelResumen = new System.Windows.Forms.Panel();
            this.labelTotalGeneral = new System.Windows.Forms.Label();
            this.labelImpuestos = new System.Windows.Forms.Label();
            this.labelSubtotal = new System.Windows.Forms.Label();
            this.labelNumeroFacturas = new System.Windows.Forms.Label();
            this.panelAcciones = new System.Windows.Forms.Panel();
            this.btnSolicitarCancelacion = new System.Windows.Forms.Button();
            this.btnEnviarCorreo = new System.Windows.Forms.Button();
            this.btnGuardarCopia = new System.Windows.Forms.Button();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.btnVerPantalla = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.tabControlEncabezado.SuspendLayout();
            this.panelFiltros.SuspendLayout();
            this.panelCentral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridFacturas)).BeginInit();
            this.panelInferior.SuspendLayout();
            this.panelResumen.SuspendLayout();
            this.panelAcciones.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.White;
            this.panelHeader.Controls.Add(this.tabControlEncabezado);
            this.panelHeader.Controls.Add(this.labelTitulo);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Padding = new System.Windows.Forms.Padding(16, 10, 16, 4);
            this.panelHeader.Size = new System.Drawing.Size(984, 70);
            this.panelHeader.TabIndex = 0;
            // 
            // tabControlEncabezado
            // 
            this.tabControlEncabezado.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControlEncabezado.Controls.Add(this.tabPageFacturasVentas);
            this.tabControlEncabezado.Controls.Add(this.tabPageFacturasGlobales);
            this.tabControlEncabezado.Controls.Add(this.tabPageClientesFacturacion);
            this.tabControlEncabezado.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControlEncabezado.Location = new System.Drawing.Point(16, 30);
            this.tabControlEncabezado.Multiline = true;
            this.tabControlEncabezado.Name = "tabControlEncabezado";
            this.tabControlEncabezado.SelectedIndex = 0;
            this.tabControlEncabezado.Size = new System.Drawing.Size(952, 36);
            this.tabControlEncabezado.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControlEncabezado.TabIndex = 1;
            // 
            // tabPageFacturasVentas
            // 
            this.tabPageFacturasVentas.Location = new System.Drawing.Point(4, 4);
            this.tabPageFacturasVentas.Name = "tabPageFacturasVentas";
            this.tabPageFacturasVentas.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFacturasVentas.Size = new System.Drawing.Size(944, 8);
            this.tabPageFacturasVentas.TabIndex = 0;
            this.tabPageFacturasVentas.Text = "Facturas por ventas";
            this.tabPageFacturasVentas.UseVisualStyleBackColor = true;
            // 
            // tabPageFacturasGlobales
            // 
            this.tabPageFacturasGlobales.Location = new System.Drawing.Point(4, 4);
            this.tabPageFacturasGlobales.Name = "tabPageFacturasGlobales";
            this.tabPageFacturasGlobales.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFacturasGlobales.Size = new System.Drawing.Size(944, 8);
            this.tabPageFacturasGlobales.TabIndex = 1;
            this.tabPageFacturasGlobales.Text = "Facturas globales";
            this.tabPageFacturasGlobales.UseVisualStyleBackColor = true;
            // 
            // tabPageClientesFacturacion
            // 
            this.tabPageClientesFacturacion.Location = new System.Drawing.Point(4, 4);
            this.tabPageClientesFacturacion.Name = "tabPageClientesFacturacion";
            this.tabPageClientesFacturacion.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageClientesFacturacion.Size = new System.Drawing.Size(944, 8);
            this.tabPageClientesFacturacion.TabIndex = 2;
            this.tabPageClientesFacturacion.Text = "Clientes de facturación";
            this.tabPageClientesFacturacion.UseVisualStyleBackColor = true;
            // 
            // labelTitulo
            // 
            this.labelTitulo.AutoSize = true;
            this.labelTitulo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(70)))), ((int)(((byte)(150)))));
            this.labelTitulo.Location = new System.Drawing.Point(16, 9);
            this.labelTitulo.Name = "labelTitulo";
            this.labelTitulo.Size = new System.Drawing.Size(94, 20);
            this.labelTitulo.TabIndex = 0;
            this.labelTitulo.Text = "FACTURACIÓN";
            // 
            // panelFiltros
            // 
            this.panelFiltros.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelFiltros.Controls.Add(this.comboPeriodo);
            this.panelFiltros.Controls.Add(this.labelMostrarFacturas);
            this.panelFiltros.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFiltros.Location = new System.Drawing.Point(0, 70);
            this.panelFiltros.Name = "panelFiltros";
            this.panelFiltros.Padding = new System.Windows.Forms.Padding(16, 6, 16, 6);
            this.panelFiltros.Size = new System.Drawing.Size(984, 32);
            this.panelFiltros.TabIndex = 1;
            // 
            // comboPeriodo
            // 
            this.comboPeriodo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPeriodo.FormattingEnabled = true;
            this.comboPeriodo.Items.AddRange(new object[] {
            "Febrero 2026",
            "Enero 2026",
            "Diciembre 2025"});
            this.comboPeriodo.Location = new System.Drawing.Point(140, 6);
            this.comboPeriodo.Name = "comboPeriodo";
            this.comboPeriodo.Size = new System.Drawing.Size(180, 23);
            this.comboPeriodo.TabIndex = 1;
            // 
            // labelMostrarFacturas
            // 
            this.labelMostrarFacturas.AutoSize = true;
            this.labelMostrarFacturas.Location = new System.Drawing.Point(16, 9);
            this.labelMostrarFacturas.Name = "labelMostrarFacturas";
            this.labelMostrarFacturas.Size = new System.Drawing.Size(118, 15);
            this.labelMostrarFacturas.TabIndex = 0;
            this.labelMostrarFacturas.Text = "Mostrar facturas de";
            // 
            // panelCentral
            // 
            this.panelCentral.Controls.Add(this.gridFacturas);
            this.panelCentral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCentral.Location = new System.Drawing.Point(0, 102);
            this.panelCentral.Name = "panelCentral";
            this.panelCentral.Padding = new System.Windows.Forms.Padding(16, 6, 16, 6);
            this.panelCentral.Size = new System.Drawing.Size(984, 379);
            this.panelCentral.TabIndex = 2;
            // 
            // gridFacturas
            // 
            this.gridFacturas.AllowUserToAddRows = false;
            this.gridFacturas.AllowUserToDeleteRows = false;
            this.gridFacturas.AllowUserToResizeRows = false;
            this.gridFacturas.BackgroundColor = System.Drawing.Color.White;
            this.gridFacturas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gridFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridFacturas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFecha,
            this.colSerie,
            this.colFolio,
            this.colCliente,
            this.colSubtotal,
            this.colImpuestos,
            this.colTotal,
            this.colFolioVenta,
            this.colTipo,
            this.colEstado});
            this.gridFacturas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridFacturas.Location = new System.Drawing.Point(16, 6);
            this.gridFacturas.MultiSelect = false;
            this.gridFacturas.Name = "gridFacturas";
            this.gridFacturas.ReadOnly = true;
            this.gridFacturas.RowHeadersVisible = false;
            this.gridFacturas.RowTemplate.Height = 24;
            this.gridFacturas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridFacturas.Size = new System.Drawing.Size(952, 367);
            this.gridFacturas.TabIndex = 0;
            // 
            // colFecha
            // 
            this.colFecha.HeaderText = "Fecha";
            this.colFecha.Name = "colFecha";
            this.colFecha.ReadOnly = true;
            // 
            // colSerie
            // 
            this.colSerie.HeaderText = "Serie";
            this.colSerie.Name = "colSerie";
            this.colSerie.ReadOnly = true;
            // 
            // colFolio
            // 
            this.colFolio.HeaderText = "Folio";
            this.colFolio.Name = "colFolio";
            this.colFolio.ReadOnly = true;
            // 
            // colCliente
            // 
            this.colCliente.HeaderText = "Cliente";
            this.colCliente.Name = "colCliente";
            this.colCliente.ReadOnly = true;
            this.colCliente.Width = 180;
            // 
            // colSubtotal
            // 
            this.colSubtotal.HeaderText = "Subtotal";
            this.colSubtotal.Name = "colSubtotal";
            this.colSubtotal.ReadOnly = true;
            // 
            // colImpuestos
            // 
            this.colImpuestos.HeaderText = "Impuestos";
            this.colImpuestos.Name = "colImpuestos";
            this.colImpuestos.ReadOnly = true;
            // 
            // colTotal
            // 
            this.colTotal.HeaderText = "Total";
            this.colTotal.Name = "colTotal";
            this.colTotal.ReadOnly = true;
            // 
            // colFolioVenta
            // 
            this.colFolioVenta.HeaderText = "Folio Venta";
            this.colFolioVenta.Name = "colFolioVenta";
            this.colFolioVenta.ReadOnly = true;
            // 
            // colTipo
            // 
            this.colTipo.HeaderText = "Tipo";
            this.colTipo.Name = "colTipo";
            this.colTipo.ReadOnly = true;
            // 
            // colEstado
            // 
            this.colEstado.HeaderText = "Estado";
            this.colEstado.Name = "colEstado";
            this.colEstado.ReadOnly = true;
            // 
            // panelInferior
            // 
            this.panelInferior.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelInferior.Controls.Add(this.panelResumen);
            this.panelInferior.Controls.Add(this.panelAcciones);
            this.panelInferior.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelInferior.Location = new System.Drawing.Point(0, 481);
            this.panelInferior.Name = "panelInferior";
            this.panelInferior.Padding = new System.Windows.Forms.Padding(16, 4, 16, 8);
            this.panelInferior.Size = new System.Drawing.Size(984, 60);
            this.panelInferior.TabIndex = 3;
            // 
            // panelResumen
            // 
            this.panelResumen.AutoSize = true;
            this.panelResumen.Controls.Add(this.labelTotalGeneral);
            this.panelResumen.Controls.Add(this.labelImpuestos);
            this.panelResumen.Controls.Add(this.labelSubtotal);
            this.panelResumen.Controls.Add(this.labelNumeroFacturas);
            this.panelResumen.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelResumen.Location = new System.Drawing.Point(16, 4);
            this.panelResumen.Name = "panelResumen";
            this.panelResumen.Size = new System.Drawing.Size(368, 48);
            this.panelResumen.TabIndex = 0;
            // 
            // labelTotalGeneral
            // 
            this.labelTotalGeneral.AutoSize = true;
            this.labelTotalGeneral.Location = new System.Drawing.Point(3, 30);
            this.labelTotalGeneral.Name = "labelTotalGeneral";
            this.labelTotalGeneral.Size = new System.Drawing.Size(54, 15);
            this.labelTotalGeneral.TabIndex = 3;
            this.labelTotalGeneral.Text = "Total: $0";
            // 
            // labelImpuestos
            // 
            this.labelImpuestos.AutoSize = true;
            this.labelImpuestos.Location = new System.Drawing.Point(184, 15);
            this.labelImpuestos.Name = "labelImpuestos";
            this.labelImpuestos.Size = new System.Drawing.Size(87, 15);
            this.labelImpuestos.TabIndex = 2;
            this.labelImpuestos.Text = "Impuestos: $0";
            // 
            // labelSubtotal
            // 
            this.labelSubtotal.AutoSize = true;
            this.labelSubtotal.Location = new System.Drawing.Point(92, 15);
            this.labelSubtotal.Name = "labelSubtotal";
            this.labelSubtotal.Size = new System.Drawing.Size(72, 15);
            this.labelSubtotal.TabIndex = 1;
            this.labelSubtotal.Text = "Subtotal: $0";
            // 
            // labelNumeroFacturas
            // 
            this.labelNumeroFacturas.AutoSize = true;
            this.labelNumeroFacturas.Location = new System.Drawing.Point(3, 15);
            this.labelNumeroFacturas.Name = "labelNumeroFacturas";
            this.labelNumeroFacturas.Size = new System.Drawing.Size(60, 15);
            this.labelNumeroFacturas.TabIndex = 0;
            this.labelNumeroFacturas.Text = "0 facturas";
            // 
            // panelAcciones
            // 
            this.panelAcciones.Controls.Add(this.btnSolicitarCancelacion);
            this.panelAcciones.Controls.Add(this.btnEnviarCorreo);
            this.panelAcciones.Controls.Add(this.btnGuardarCopia);
            this.panelAcciones.Controls.Add(this.btnImprimir);
            this.panelAcciones.Controls.Add(this.btnVerPantalla);
            this.panelAcciones.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelAcciones.Location = new System.Drawing.Point(428, 4);
            this.panelAcciones.Name = "panelAcciones";
            this.panelAcciones.Size = new System.Drawing.Size(540, 48);
            this.panelAcciones.TabIndex = 1;
            // 
            // btnSolicitarCancelacion
            // 
            this.btnSolicitarCancelacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSolicitarCancelacion.Location = new System.Drawing.Point(424, 11);
            this.btnSolicitarCancelacion.Name = "btnSolicitarCancelacion";
            this.btnSolicitarCancelacion.Size = new System.Drawing.Size(113, 27);
            this.btnSolicitarCancelacion.TabIndex = 4;
            this.btnSolicitarCancelacion.Text = "Solicitar cancelación";
            this.btnSolicitarCancelacion.UseVisualStyleBackColor = true;
            // 
            // btnEnviarCorreo
            // 
            this.btnEnviarCorreo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEnviarCorreo.Location = new System.Drawing.Point(322, 11);
            this.btnEnviarCorreo.Name = "btnEnviarCorreo";
            this.btnEnviarCorreo.Size = new System.Drawing.Size(96, 27);
            this.btnEnviarCorreo.TabIndex = 3;
            this.btnEnviarCorreo.Text = "Enviar por correo";
            this.btnEnviarCorreo.UseVisualStyleBackColor = true;
            // 
            // btnGuardarCopia
            // 
            this.btnGuardarCopia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGuardarCopia.Location = new System.Drawing.Point(219, 11);
            this.btnGuardarCopia.Name = "btnGuardarCopia";
            this.btnGuardarCopia.Size = new System.Drawing.Size(97, 27);
            this.btnGuardarCopia.TabIndex = 2;
            this.btnGuardarCopia.Text = "Guardar copia";
            this.btnGuardarCopia.UseVisualStyleBackColor = true;
            // 
            // btnImprimir
            // 
            this.btnImprimir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImprimir.Location = new System.Drawing.Point(140, 11);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(73, 27);
            this.btnImprimir.TabIndex = 1;
            this.btnImprimir.Text = "Imprimir...";
            this.btnImprimir.UseVisualStyleBackColor = true;
            // 
            // btnVerPantalla
            // 
            this.btnVerPantalla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVerPantalla.Location = new System.Drawing.Point(52, 11);
            this.btnVerPantalla.Name = "btnVerPantalla";
            this.btnVerPantalla.Size = new System.Drawing.Size(82, 27);
            this.btnVerPantalla.TabIndex = 0;
            this.btnVerPantalla.Text = "Ver en pantalla";
            this.btnVerPantalla.UseVisualStyleBackColor = true;
            // 
            // factura (UserControl)
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelCentral);
            this.Controls.Add(this.panelInferior);
            this.Controls.Add(this.panelFiltros);
            this.Controls.Add(this.panelHeader);
            this.Name = "factura";
            this.Size = new System.Drawing.Size(984, 541);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.tabControlEncabezado.ResumeLayout(false);
            this.panelFiltros.ResumeLayout(false);
            this.panelFiltros.PerformLayout();
            this.panelCentral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridFacturas)).EndInit();
            this.panelInferior.ResumeLayout(false);
            this.panelInferior.PerformLayout();
            this.panelResumen.ResumeLayout(false);
            this.panelResumen.PerformLayout();
            this.panelAcciones.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.TabControl tabControlEncabezado;
        private System.Windows.Forms.TabPage tabPageFacturasVentas;
        private System.Windows.Forms.TabPage tabPageFacturasGlobales;
        private System.Windows.Forms.TabPage tabPageClientesFacturacion;
        private System.Windows.Forms.Panel panelFiltros;
        private System.Windows.Forms.ComboBox comboPeriodo;
        private System.Windows.Forms.Label labelMostrarFacturas;
        private System.Windows.Forms.Panel panelCentral;
        private System.Windows.Forms.DataGridView gridFacturas;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSerie;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFolio;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubtotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImpuestos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFolioVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstado;
        private System.Windows.Forms.Panel panelInferior;
        private System.Windows.Forms.Panel panelResumen;
        private System.Windows.Forms.Label labelTotalGeneral;
        private System.Windows.Forms.Label labelImpuestos;
        private System.Windows.Forms.Label labelSubtotal;
        private System.Windows.Forms.Label labelNumeroFacturas;
        private System.Windows.Forms.Panel panelAcciones;
        private System.Windows.Forms.Button btnSolicitarCancelacion;
        private System.Windows.Forms.Button btnEnviarCorreo;
        private System.Windows.Forms.Button btnGuardarCopia;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Button btnVerPantalla;
    }
}