using System;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class ModificarProducto : Form
    {
        private productos _editor;

        public ModificarProducto()
        {
            InitializeComponent();
            if (pnlEditor != null)
                pnlEditor.Visible = false;
            if (pnlCodigo != null)
                pnlCodigo.Visible = true;
        }

        private void InicializarEditor()
        {
            if (_editor != null)
                return;

            _editor = new productos();
            _editor.TopLevel = false;
            _editor.FormBorderStyle = FormBorderStyle.None;
            _editor.Dock = DockStyle.Fill;

            _editor.PrepararComoEditorEmbebido();

            pnlEditor.Controls.Add(_editor);
            _editor.Show();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Cargar();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            productos p = ObtenerModuloProductos();
            if (p != null)
            {
                p.NavegarANuevo();
                return;
            }

            this.Close();
        }

        private Form1 ObtenerFormPrincipal()
        {
            Form1 main = this.TopLevelControl as Form1;
            if (main != null)
                return main;

            Control c = this.Parent;
            while (c != null)
            {
                Form1 f = c as Form1;
                if (f != null)
                    return f;
                c = c.Parent;
            }

            return null;
        }

        private productos ObtenerModuloProductos()
        {
            Control c = this.Parent;
            while (c != null)
            {
                productos p = c as productos;
                if (p != null)
                    return p;
                c = c.Parent;
            }

            return null;
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                Cargar();
            }
        }

        private void Cargar()
        {
            string codigo = txtCodigo == null ? string.Empty : txtCodigo.Text.Trim();
            if (string.IsNullOrWhiteSpace(codigo))
            {
                MessageBox.Show("Ingrese el código de barras.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtCodigo != null)
                    txtCodigo.Focus();
                return;
            }

            InicializarEditor();

            bool ok = _editor.CargarProductoParaEdicion(codigo);
            if (!ok)
            {
                if (txtCodigo != null)
                {
                    txtCodigo.SelectAll();
                    txtCodigo.Focus();
                }
                return;
            }

            if (pnlCodigo != null)
                pnlCodigo.Visible = false;
            if (pnlEditor != null)
            {
                pnlEditor.Visible = true;
                pnlEditor.BringToFront();
            }
        }
    }
}
