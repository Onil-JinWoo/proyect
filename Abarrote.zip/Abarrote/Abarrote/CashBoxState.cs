namespace Abarrote
{
    public static class CashBoxState
    {
        public static decimal EfectivoEnCaja { get; set; }
    }
}
