using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class InventarioUserControl : UserControl
    {
        private ProductoInfo _producto;

        private Label _lblDescripcion;
        private Label _lblHay;
        private NumericUpDown _numAgregar;
        private NumericUpDown _numCosto;
        private NumericUpDown _numVenta;
        private NumericUpDown _numMayoreo;
        private Button _btnGuardar;
        private Label _lblMensaje;

        public InventarioUserControl()
        {
            InitializeComponent();

            if (txtCodigoProducto != null)
                txtCodigoProducto.KeyDown += TxtCodigoProducto_KeyDown;
            if (btnAgregar != null)
                btnAgregar.Click += (s, e) => EnfocarCodigoProducto();

            EnsureEditorEmbebido();
        }

        private void TxtCodigoProducto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                CargarProductoDesdeCodigo();
            }
        }

        private void EnfocarCodigoProducto()
        {
            if (txtCodigoProducto != null)
            {
                txtCodigoProducto.Focus();
                txtCodigoProducto.SelectAll();
            }
        }

        private void EnsureEditorEmbebido()
        {
            if (pnlAgregarInventario == null)
                return;
            if (_lblDescripcion != null)
                return;

            int xLabel = 25;
            int xValue = 135;

            Label lblDesc = new Label();
            lblDesc.AutoSize = true;
            lblDesc.Font = new Font("Segoe UI", 9F);
            lblDesc.Text = "Descripción";
            lblDesc.Location = new Point(xLabel + 35, 105);

            _lblDescripcion = new Label();
            _lblDescripcion.AutoSize = false;
            _lblDescripcion.Font = new Font("Segoe UI", 9F);
            _lblDescripcion.Location = new Point(xValue, 105);
            _lblDescripcion.Size = new Size(780, 20);

            Label lblHay = new Label();
            lblHay.AutoSize = true;
            lblHay.Font = new Font("Segoe UI", 9F);
            lblHay.Text = "Hay";
            lblHay.Location = new Point(xLabel + 70, 135);

            _lblHay = new Label();
            _lblHay.AutoSize = false;
            _lblHay.Font = new Font("Segoe UI", 9F);
            _lblHay.Location = new Point(xValue, 135);
            _lblHay.Size = new Size(120, 20);

            Label lblAgregar = new Label();
            lblAgregar.AutoSize = true;
            lblAgregar.Font = new Font("Segoe UI", 9F);
            lblAgregar.Text = "Agregar";
            lblAgregar.Location = new Point(xLabel + 52, 165);

            _numAgregar = new NumericUpDown();
            _numAgregar.Location = new Point(xValue, 162);
            _numAgregar.Size = new Size(120, 23);
            _numAgregar.Maximum = 1000000;
            _numAgregar.DecimalPlaces = 0;

            Label lblCosto = new Label();
            lblCosto.AutoSize = true;
            lblCosto.Font = new Font("Segoe UI", 9F);
            lblCosto.Text = "Precio Costo";
            lblCosto.Location = new Point(xLabel + 40, 197);

            _numCosto = new NumericUpDown();
            _numCosto.Location = new Point(xValue, 194);
            _numCosto.Size = new Size(120, 23);
            _numCosto.Maximum = 100000000;
            _numCosto.DecimalPlaces = 2;
            _numCosto.ThousandsSeparator = true;

            Label lblVenta = new Label();
            lblVenta.AutoSize = true;
            lblVenta.Font = new Font("Segoe UI", 9F);
            lblVenta.Text = "Precio Venta";
            lblVenta.Location = new Point(xLabel + 42, 229);

            _numVenta = new NumericUpDown();
            _numVenta.Location = new Point(xValue, 226);
            _numVenta.Size = new Size(120, 23);
            _numVenta.Maximum = 100000000;
            _numVenta.DecimalPlaces = 2;
            _numVenta.ThousandsSeparator = true;

            Label lblMayoreo = new Label();
            lblMayoreo.AutoSize = true;
            lblMayoreo.Font = new Font("Segoe UI", 9F);
            lblMayoreo.Text = "Precio Mayoreo";
            lblMayoreo.Location = new Point(xLabel + 22, 261);

            _numMayoreo = new NumericUpDown();
            _numMayoreo.Location = new Point(xValue, 258);
            _numMayoreo.Size = new Size(120, 23);
            _numMayoreo.Maximum = 100000000;
            _numMayoreo.DecimalPlaces = 2;
            _numMayoreo.ThousandsSeparator = true;

            _btnGuardar = new Button();
            _btnGuardar.Text = "✓ Agregar cantidad a inventario";
            _btnGuardar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _btnGuardar.FlatStyle = FlatStyle.Flat;
            _btnGuardar.FlatAppearance.BorderColor = Color.Silver;
            _btnGuardar.Size = new Size(240, 34);
            _btnGuardar.Location = new Point(xValue, 292);
            _btnGuardar.Click += (s, e) => GuardarAjuste();

            _lblMensaje = new Label();
            _lblMensaje.AutoSize = false;
            _lblMensaje.Font = new Font("Segoe UI", 8.5F);
            _lblMensaje.ForeColor = Color.FromArgb(80, 80, 80);
            _lblMensaje.BackColor = Color.FromArgb(255, 249, 220);
            _lblMensaje.BorderStyle = BorderStyle.FixedSingle;
            _lblMensaje.Location = new Point(xValue, 332);
            _lblMensaje.Size = new Size(780, 40);
            _lblMensaje.Visible = false;

            pnlAgregarInventario.Controls.Add(lblDesc);
            pnlAgregarInventario.Controls.Add(_lblDescripcion);
            pnlAgregarInventario.Controls.Add(lblHay);
            pnlAgregarInventario.Controls.Add(_lblHay);
            pnlAgregarInventario.Controls.Add(lblAgregar);
            pnlAgregarInventario.Controls.Add(_numAgregar);
            pnlAgregarInventario.Controls.Add(lblCosto);
            pnlAgregarInventario.Controls.Add(_numCosto);
            pnlAgregarInventario.Controls.Add(lblVenta);
            pnlAgregarInventario.Controls.Add(_numVenta);
            pnlAgregarInventario.Controls.Add(lblMayoreo);
            pnlAgregarInventario.Controls.Add(_numMayoreo);
            pnlAgregarInventario.Controls.Add(_btnGuardar);
            pnlAgregarInventario.Controls.Add(_lblMensaje);

            LimpiarEditor();
        }

        private void LimpiarEditor()
        {
            _producto = null;
            if (_lblDescripcion != null) _lblDescripcion.Text = string.Empty;
            if (_lblHay != null) _lblHay.Text = string.Empty;
            if (_numAgregar != null) _numAgregar.Value = 0;
            if (_numCosto != null) _numCosto.Value = 0;
            if (_numVenta != null) _numVenta.Value = 0;
            if (_numMayoreo != null) _numMayoreo.Value = 0;
            if (_lblMensaje != null) _lblMensaje.Visible = false;
        }

        private void CargarProductoDesdeCodigo()
        {
            EnsureEditorEmbebido();
            string codigo = txtCodigoProducto == null ? string.Empty : (txtCodigoProducto.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            _producto = DatabaseHelper.ObtenerProductoPorCodigoBarras(codigo);
            if (_producto == null)
            {
                MessageBox.Show("Producto no encontrado.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                EnfocarCodigoProducto();
                LimpiarEditor();
                return;
            }

            if (_lblDescripcion != null) _lblDescripcion.Text = _producto.Descripcion;
            if (_lblHay != null) _lblHay.Text = _producto.StockActual.ToString(CultureInfo.CurrentCulture);
            if (_numCosto != null) _numCosto.Value = ClampDecimal(_producto.PrecioCosto, _numCosto.Maximum);
            if (_numVenta != null) _numVenta.Value = ClampDecimal(_producto.PrecioVenta, _numVenta.Maximum);
            if (_numMayoreo != null) _numMayoreo.Value = ClampDecimal(_producto.PrecioMayoreo, _numMayoreo.Maximum);
            if (_numAgregar != null)
            {
                _numAgregar.Value = 0;
                _numAgregar.Focus();
                _numAgregar.Select(0, _numAgregar.Text.Length);
            }
            if (_lblMensaje != null) _lblMensaje.Visible = false;
        }

        private static decimal ClampDecimal(decimal value, decimal max)
        {
            if (value < 0m) return 0m;
            if (value > max) return max;
            return value;
        }

        private void GuardarAjuste()
        {
            if (_producto == null)
            {
                MessageBox.Show("Primero capture el código del producto y presione Enter.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                EnfocarCodigoProducto();
                return;
            }

            int agregar = _numAgregar == null ? 0 : (int)_numAgregar.Value;
            if (agregar <= 0)
            {
                MessageBox.Show("Captura la cantidad a agregar.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_numAgregar != null) _numAgregar.Focus();
                return;
            }

            decimal costo = _numCosto == null ? 0m : _numCosto.Value;
            decimal venta = _numVenta == null ? 0m : _numVenta.Value;
            decimal mayoreo = _numMayoreo == null ? 0m : _numMayoreo.Value;

            string err;
            if (!DatabaseHelper.AgregarInventarioYActualizarPrecios(_producto.CodigoBarras, agregar, costo, venta, mayoreo, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo actualizar el inventario." : err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_lblMensaje != null)
            {
                _lblMensaje.Text = string.Format(CultureInfo.CurrentCulture,
                    "Se recibieron {0} de inventario para el producto, el costo se quedo igual en {1}, el precio de venta sera de {2} y el precio de mayoreo de {3}.",
                    agregar,
                    costo.ToString("C2"),
                    venta.ToString("C2"),
                    mayoreo.ToString("C2"));
                _lblMensaje.Visible = true;
            }

            txtCodigoProducto.Clear();
            EnfocarCodigoProducto();
            LimpiarEditor();
        }
    }
}
