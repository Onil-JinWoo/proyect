using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class CashEntryForm : Form
    {
        private Panel _hdr;
        private Label _lblHdr;
        private Label _lblCantidad;
        private TextBox _txtMonto;
        private Label _lblComentarios;
        private TextBox _txtComentarios;
        private Button _btnGuardar;
        private Button _btnCancelar;

        public decimal Monto { get; private set; }
        public string Comentarios { get; private set; }

        public CashEntryForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Registro de Entradas de Efectivo";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(440, 200);

            _hdr = new Panel();
            _hdr.Location = new Point(0, 0);
            _hdr.Size = new Size(440, 30);
            _hdr.BackColor = Color.FromArgb(0, 128, 128);

            _lblHdr = new Label();
            _lblHdr.AutoSize = false;
            _lblHdr.Location = new Point(10, 5);
            _lblHdr.Size = new Size(320, 20);
            _lblHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            _lblHdr.ForeColor = Color.White;
            _lblHdr.Text = "ENTRADA DE EFECTIVO";

            _hdr.Controls.Add(_lblHdr);

            _lblCantidad = new Label();
            _lblCantidad.AutoSize = true;
            _lblCantidad.Location = new Point(20, 45);
            _lblCantidad.Font = new Font("Segoe UI", 9F);
            _lblCantidad.Text = "Cantidad:";

            _txtMonto = new TextBox();
            _txtMonto.Location = new Point(20, 65);
            _txtMonto.Size = new Size(240, 30);
            _txtMonto.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _txtMonto.Text = 0m.ToString("C2", CultureInfo.CurrentCulture);
            _txtMonto.Enter += (s, e) =>
            {
                if (_txtMonto != null)
                    _txtMonto.SelectAll();
            };

            _lblComentarios = new Label();
            _lblComentarios.AutoSize = true;
            _lblComentarios.Location = new Point(20, 110);
            _lblComentarios.Font = new Font("Segoe UI", 9F);
            _lblComentarios.Text = "Comentarios:";

            _txtComentarios = new TextBox();
            _txtComentarios.Location = new Point(20, 130);
            _txtComentarios.Size = new Size(240, 23);
            _txtComentarios.Text = "Entrada de dinero";

            _btnGuardar = new Button();
            _btnGuardar.Location = new Point(300, 55);
            _btnGuardar.Size = new Size(120, 32);
            _btnGuardar.Text = "Guardar";
            _btnGuardar.Click += btnGuardar_Click;

            _btnCancelar = new Button();
            _btnCancelar.Location = new Point(300, 95);
            _btnCancelar.Size = new Size(120, 32);
            _btnCancelar.Text = "Cancelar";
            _btnCancelar.Click += btnCancelar_Click;

            AcceptButton = _btnGuardar;
            CancelButton = _btnCancelar;

            Controls.Add(_hdr);
            Controls.Add(_lblCantidad);
            Controls.Add(_txtMonto);
            Controls.Add(_lblComentarios);
            Controls.Add(_txtComentarios);
            Controls.Add(_btnGuardar);
            Controls.Add(_btnCancelar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            decimal monto;
            if (!TryParseMonto(_txtMonto == null ? string.Empty : (_txtMonto.Text ?? string.Empty), out monto) || monto <= 0m)
            {
                MessageBox.Show("Captura un monto válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtMonto != null)
                {
                    _txtMonto.SelectAll();
                    _txtMonto.Focus();
                }
                return;
            }

            Monto = monto;
            Comentarios = _txtComentarios == null ? string.Empty : (_txtComentarios.Text ?? string.Empty).Trim();

            CashBoxState.EfectivoEnCaja += monto;

            string err;
            DatabaseHelper.RegistrarMovimientoCaja("ENTRADA", monto, Comentarios, UserSessionState.Usuario, out err);

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private static bool TryParseMonto(string value, out decimal monto)
        {
            monto = 0m;
            string v = (value ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(v))
                return false;

            if (decimal.TryParse(v, NumberStyles.Currency, CultureInfo.CurrentCulture, out monto))
                return true;

            return decimal.TryParse(v, NumberStyles.Number, CultureInfo.CurrentCulture, out monto);
        }
    }
}
