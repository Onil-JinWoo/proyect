namespace Abarrote
{
    partial class ClientesUserControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            this.lblClientesTitle = new System.Windows.Forms.Label();
            this.lblAdminDesc = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.btnExportar = new System.Windows.Forms.Button();
            this.lstClientes = new System.Windows.Forms.ListView();
            this.colFolio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNombre = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colContacto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.picClienteAvatar = new System.Windows.Forms.PictureBox();
            this.chkTieneCredito = new System.Windows.Forms.CheckBox();
            this.txtLimiteCreditoMonto = new System.Windows.Forms.TextBox();
            this.cboLimiteCreditoTipo = new System.Windows.Forms.ComboBox();
            this.lblLimiteCredito = new System.Windows.Forms.Label();
            this.txtNotas = new System.Windows.Forms.TextBox();
            this.txtCodigoPostal = new System.Windows.Forms.TextBox();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.cboMunicipio = new System.Windows.Forms.ComboBox();
            this.txtColonia = new System.Windows.Forms.TextBox();
            this.txtDomicilio2 = new System.Windows.Forms.TextBox();
            this.txtDomicilio1 = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtApellidos = new System.Windows.Forms.TextBox();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.lblNotas = new System.Windows.Forms.Label();
            this.lblCodigoPostal = new System.Windows.Forms.Label();
            this.lblMunicipioEstado = new System.Windows.Forms.Label();
            this.lblColonia = new System.Windows.Forms.Label();
            this.lblDomicilio2 = new System.Windows.Forms.Label();
            this.lblDomicilio1 = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.lblNombres = new System.Windows.Forms.Label();
            this.lblNuevoCliente = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnNuevoCliente = new System.Windows.Forms.Button();
            this.pnlLeft.SuspendLayout();
            this.pnlRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClienteAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // lblClientesTitle
            // 
            this.lblClientesTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(120)))), ((int)(((byte)(60)))));
            this.lblClientesTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblClientesTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblClientesTitle.ForeColor = System.Drawing.Color.White;
            this.lblClientesTitle.Location = new System.Drawing.Point(10, 10);
            this.lblClientesTitle.Name = "lblClientesTitle";
            this.lblClientesTitle.Padding = new System.Windows.Forms.Padding(8, 5, 0, 5);
            this.lblClientesTitle.Size = new System.Drawing.Size(1280, 35);
            this.lblClientesTitle.TabIndex = 0;
            this.lblClientesTitle.Text = "CLIENTES  -  Administración de clientes";
            this.lblClientesTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAdminDesc
            // 
            this.lblAdminDesc.AutoSize = true;
            this.lblAdminDesc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblAdminDesc.Location = new System.Drawing.Point(15, 48);
            this.lblAdminDesc.Name = "lblAdminDesc";
            this.lblAdminDesc.Size = new System.Drawing.Size(577, 38);
            this.lblAdminDesc.TabIndex = 1;
            this.lblAdminDesc.Text = "ADMINISTRACION DE CLIENTES\r\nAdministra a todos los clientes de tu negocio (crédit" +
    "o, facturación, etc.) de forma centralizada.";
            // 
            // pnlLeft
            // 
            this.pnlLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeft.BackColor = System.Drawing.Color.White;
            this.pnlLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLeft.Controls.Add(this.btnExportar);
            this.pnlLeft.Controls.Add(this.lstClientes);
            this.pnlLeft.Controls.Add(this.txtBuscar);
            this.pnlLeft.Location = new System.Drawing.Point(15, 95);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(350, 481);
            this.pnlLeft.TabIndex = 2;
            // 
            // btnExportar
            // 
            this.btnExportar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnExportar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnExportar.Location = new System.Drawing.Point(10, 440);
            this.btnExportar.Name = "btnExportar";
            this.btnExportar.Size = new System.Drawing.Size(100, 28);
            this.btnExportar.TabIndex = 2;
            this.btnExportar.Text = "Exportar...";
            this.btnExportar.UseVisualStyleBackColor = true;
            // 
            // lstClientes
            // 
            this.lstClientes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colFolio,
            this.colNombre,
            this.colContacto});
            this.lstClientes.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstClientes.FullRowSelect = true;
            this.lstClientes.HideSelection = false;
            this.lstClientes.Location = new System.Drawing.Point(10, 40);
            this.lstClientes.Name = "lstClientes";
            this.lstClientes.Size = new System.Drawing.Size(325, 390);
            this.lstClientes.TabIndex = 1;
            this.lstClientes.UseCompatibleStateImageBehavior = false;
            this.lstClientes.View = System.Windows.Forms.View.Details;
            // 
            // colFolio
            // 
            this.colFolio.Text = "Folio";
            this.colFolio.Width = 80;
            // 
            // colNombre
            // 
            this.colNombre.Text = "Nombre";
            this.colNombre.Width = 140;
            // 
            // colContacto
            // 
            this.colContacto.Text = "Contacto";
            this.colContacto.Width = 170;
            // 
            // txtBuscar
            // 
            this.txtBuscar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtBuscar.Location = new System.Drawing.Point(10, 10);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(325, 23);
            this.txtBuscar.TabIndex = 0;
            // 
            // pnlRight
            // 
            this.pnlRight.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlRight.BackColor = System.Drawing.Color.White;
            this.pnlRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRight.Controls.Add(this.picClienteAvatar);
            this.pnlRight.Controls.Add(this.chkTieneCredito);
            this.pnlRight.Controls.Add(this.txtLimiteCreditoMonto);
            this.pnlRight.Controls.Add(this.cboLimiteCreditoTipo);
            this.pnlRight.Controls.Add(this.lblLimiteCredito);
            this.pnlRight.Controls.Add(this.txtNotas);
            this.pnlRight.Controls.Add(this.txtCodigoPostal);
            this.pnlRight.Controls.Add(this.cboEstado);
            this.pnlRight.Controls.Add(this.cboMunicipio);
            this.pnlRight.Controls.Add(this.txtColonia);
            this.pnlRight.Controls.Add(this.txtDomicilio2);
            this.pnlRight.Controls.Add(this.txtDomicilio1);
            this.pnlRight.Controls.Add(this.txtCorreo);
            this.pnlRight.Controls.Add(this.txtTelefono);
            this.pnlRight.Controls.Add(this.txtApellidos);
            this.pnlRight.Controls.Add(this.txtNombres);
            this.pnlRight.Controls.Add(this.lblNotas);
            this.pnlRight.Controls.Add(this.lblCodigoPostal);
            this.pnlRight.Controls.Add(this.lblMunicipioEstado);
            this.pnlRight.Controls.Add(this.lblColonia);
            this.pnlRight.Controls.Add(this.lblDomicilio2);
            this.pnlRight.Controls.Add(this.lblDomicilio1);
            this.pnlRight.Controls.Add(this.lblCorreo);
            this.pnlRight.Controls.Add(this.lblTelefono);
            this.pnlRight.Controls.Add(this.lblApellidos);
            this.pnlRight.Controls.Add(this.lblNombres);
            this.pnlRight.Controls.Add(this.lblNuevoCliente);
            this.pnlRight.Controls.Add(this.btnGuardar);
            this.pnlRight.Controls.Add(this.btnEliminar);
            this.pnlRight.Controls.Add(this.btnNuevoCliente);
            this.pnlRight.Location = new System.Drawing.Point(375, 95);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Padding = new System.Windows.Forms.Padding(15);
            this.pnlRight.Size = new System.Drawing.Size(906, 481);
            this.pnlRight.TabIndex = 3;
            // 
            // picClienteAvatar
            // 
            this.picClienteAvatar.BackColor = System.Drawing.Color.Transparent;
            this.picClienteAvatar.Location = new System.Drawing.Point(600, 80);
            this.picClienteAvatar.Name = "picClienteAvatar";
            this.picClienteAvatar.Size = new System.Drawing.Size(120, 120);
            this.picClienteAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picClienteAvatar.TabIndex = 29;
            this.picClienteAvatar.TabStop = false;
            // 
            // chkTieneCredito
            // 
            this.chkTieneCredito.AutoSize = true;
            this.chkTieneCredito.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.chkTieneCredito.Location = new System.Drawing.Point(165, 450);
            this.chkTieneCredito.Name = "chkTieneCredito";
            this.chkTieneCredito.Size = new System.Drawing.Size(154, 19);
            this.chkTieneCredito.TabIndex = 25;
            this.chkTieneCredito.Text = "Tiene crédito autorizado";
            this.chkTieneCredito.UseVisualStyleBackColor = true;
            // 
            // txtLimiteCreditoMonto
            // 
            this.txtLimiteCreditoMonto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLimiteCreditoMonto.Location = new System.Drawing.Point(370, 477);
            this.txtLimiteCreditoMonto.Name = "txtLimiteCreditoMonto";
            this.txtLimiteCreditoMonto.Size = new System.Drawing.Size(100, 23);
            this.txtLimiteCreditoMonto.TabIndex = 28;
            this.txtLimiteCreditoMonto.Text = "0";
            this.txtLimiteCreditoMonto.Visible = false;
            // 
            // cboLimiteCreditoTipo
            // 
            this.cboLimiteCreditoTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLimiteCreditoTipo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboLimiteCreditoTipo.FormattingEnabled = true;
            this.cboLimiteCreditoTipo.Items.AddRange(new object[] {
            "Ilimitado",
            "De máximo:"});
            this.cboLimiteCreditoTipo.Location = new System.Drawing.Point(160, 477);
            this.cboLimiteCreditoTipo.Name = "cboLimiteCreditoTipo";
            this.cboLimiteCreditoTipo.Size = new System.Drawing.Size(200, 23);
            this.cboLimiteCreditoTipo.TabIndex = 27;
            this.cboLimiteCreditoTipo.Visible = false;
            // 
            // lblLimiteCredito
            // 
            this.lblLimiteCredito.AutoSize = true;
            this.lblLimiteCredito.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLimiteCredito.Location = new System.Drawing.Point(22, 480);
            this.lblLimiteCredito.Name = "lblLimiteCredito";
            this.lblLimiteCredito.Size = new System.Drawing.Size(96, 15);
            this.lblLimiteCredito.TabIndex = 26;
            this.lblLimiteCredito.Text = "Límite de crédito";
            this.lblLimiteCredito.Visible = false;
            // 
            // txtNotas
            // 
            this.txtNotas.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNotas.Location = new System.Drawing.Point(160, 357);
            this.txtNotas.Multiline = true;
            this.txtNotas.Name = "txtNotas";
            this.txtNotas.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNotas.Size = new System.Drawing.Size(400, 80);
            this.txtNotas.TabIndex = 24;
            // 
            // txtCodigoPostal
            // 
            this.txtCodigoPostal.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCodigoPostal.Location = new System.Drawing.Point(160, 327);
            this.txtCodigoPostal.Name = "txtCodigoPostal";
            this.txtCodigoPostal.Size = new System.Drawing.Size(100, 23);
            this.txtCodigoPostal.TabIndex = 23;
            // 
            // cboEstado
            // 
            this.cboEstado.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Location = new System.Drawing.Point(370, 297);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.Size = new System.Drawing.Size(190, 23);
            this.cboEstado.TabIndex = 22;
            // 
            // cboMunicipio
            // 
            this.cboMunicipio.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboMunicipio.FormattingEnabled = true;
            this.cboMunicipio.Location = new System.Drawing.Point(160, 297);
            this.cboMunicipio.Name = "cboMunicipio";
            this.cboMunicipio.Size = new System.Drawing.Size(200, 23);
            this.cboMunicipio.TabIndex = 21;
            // 
            // txtColonia
            // 
            this.txtColonia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtColonia.Location = new System.Drawing.Point(160, 267);
            this.txtColonia.Name = "txtColonia";
            this.txtColonia.Size = new System.Drawing.Size(250, 23);
            this.txtColonia.TabIndex = 20;
            // 
            // txtDomicilio2
            // 
            this.txtDomicilio2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDomicilio2.Location = new System.Drawing.Point(160, 237);
            this.txtDomicilio2.Name = "txtDomicilio2";
            this.txtDomicilio2.Size = new System.Drawing.Size(400, 23);
            this.txtDomicilio2.TabIndex = 19;
            // 
            // txtDomicilio1
            // 
            this.txtDomicilio1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDomicilio1.Location = new System.Drawing.Point(160, 207);
            this.txtDomicilio1.Name = "txtDomicilio1";
            this.txtDomicilio1.Size = new System.Drawing.Size(400, 23);
            this.txtDomicilio1.TabIndex = 18;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCorreo.Location = new System.Drawing.Point(160, 177);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(300, 23);
            this.txtCorreo.TabIndex = 17;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTelefono.Location = new System.Drawing.Point(160, 147);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(200, 23);
            this.txtTelefono.TabIndex = 16;
            // 
            // txtApellidos
            // 
            this.txtApellidos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtApellidos.Location = new System.Drawing.Point(160, 117);
            this.txtApellidos.Name = "txtApellidos";
            this.txtApellidos.Size = new System.Drawing.Size(300, 23);
            this.txtApellidos.TabIndex = 15;
            // 
            // txtNombres
            // 
            this.txtNombres.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNombres.Location = new System.Drawing.Point(160, 87);
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Size = new System.Drawing.Size(300, 23);
            this.txtNombres.TabIndex = 14;
            // 
            // lblNotas
            // 
            this.lblNotas.AutoSize = true;
            this.lblNotas.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNotas.Location = new System.Drawing.Point(22, 360);
            this.lblNotas.Name = "lblNotas";
            this.lblNotas.Size = new System.Drawing.Size(120, 15);
            this.lblNotas.TabIndex = 13;
            this.lblNotas.Text = "Notas / Comentarios:";
            // 
            // lblCodigoPostal
            // 
            this.lblCodigoPostal.AutoSize = true;
            this.lblCodigoPostal.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCodigoPostal.Location = new System.Drawing.Point(22, 330);
            this.lblCodigoPostal.Name = "lblCodigoPostal";
            this.lblCodigoPostal.Size = new System.Drawing.Size(84, 15);
            this.lblCodigoPostal.TabIndex = 12;
            this.lblCodigoPostal.Text = "Código Postal:";
            // 
            // lblMunicipioEstado
            // 
            this.lblMunicipioEstado.AutoSize = true;
            this.lblMunicipioEstado.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMunicipioEstado.Location = new System.Drawing.Point(22, 300);
            this.lblMunicipioEstado.Name = "lblMunicipioEstado";
            this.lblMunicipioEstado.Size = new System.Drawing.Size(110, 15);
            this.lblMunicipioEstado.TabIndex = 11;
            this.lblMunicipioEstado.Text = "Municipio / Estado:";
            // 
            // lblColonia
            // 
            this.lblColonia.AutoSize = true;
            this.lblColonia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblColonia.Location = new System.Drawing.Point(22, 270);
            this.lblColonia.Name = "lblColonia";
            this.lblColonia.Size = new System.Drawing.Size(51, 15);
            this.lblColonia.TabIndex = 10;
            this.lblColonia.Text = "Colonia:";
            // 
            // lblDomicilio2
            // 
            this.lblDomicilio2.AutoSize = true;
            this.lblDomicilio2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDomicilio2.Location = new System.Drawing.Point(22, 240);
            this.lblDomicilio2.Name = "lblDomicilio2";
            this.lblDomicilio2.Size = new System.Drawing.Size(70, 15);
            this.lblDomicilio2.TabIndex = 9;
            this.lblDomicilio2.Text = "Domicilio 2:";
            // 
            // lblDomicilio1
            // 
            this.lblDomicilio1.AutoSize = true;
            this.lblDomicilio1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDomicilio1.Location = new System.Drawing.Point(22, 210);
            this.lblDomicilio1.Name = "lblDomicilio1";
            this.lblDomicilio1.Size = new System.Drawing.Size(70, 15);
            this.lblDomicilio1.TabIndex = 8;
            this.lblDomicilio1.Text = "Domicilio 1:";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCorreo.Location = new System.Drawing.Point(22, 180);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(108, 15);
            this.lblCorreo.TabIndex = 7;
            this.lblCorreo.Text = "Correo electrónico:";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTelefono.Location = new System.Drawing.Point(22, 150);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(56, 15);
            this.lblTelefono.TabIndex = 6;
            this.lblTelefono.Text = "Teléfono:";
            // 
            // lblApellidos
            // 
            this.lblApellidos.AutoSize = true;
            this.lblApellidos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblApellidos.Location = new System.Drawing.Point(22, 120);
            this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(59, 15);
            this.lblApellidos.TabIndex = 5;
            this.lblApellidos.Text = "Apellidos:";
            // 
            // lblNombres
            // 
            this.lblNombres.AutoSize = true;
            this.lblNombres.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNombres.Location = new System.Drawing.Point(22, 90);
            this.lblNombres.Name = "lblNombres";
            this.lblNombres.Size = new System.Drawing.Size(59, 15);
            this.lblNombres.TabIndex = 4;
            this.lblNombres.Text = "Nombres:";
            // 
            // lblNuevoCliente
            // 
            this.lblNuevoCliente.AutoSize = true;
            this.lblNuevoCliente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNuevoCliente.Location = new System.Drawing.Point(18, 55);
            this.lblNuevoCliente.Name = "lblNuevoCliente";
            this.lblNuevoCliente.Size = new System.Drawing.Size(117, 21);
            this.lblNuevoCliente.TabIndex = 3;
            this.lblNuevoCliente.Text = "Nuevo cliente";
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(250, 15);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(90, 32);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "✓ Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            // 
            // btnEliminar
            // 
            this.btnEliminar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEliminar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnEliminar.Location = new System.Drawing.Point(150, 15);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(90, 32);
            this.btnEliminar.TabIndex = 1;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click_1);
            // 
            // btnNuevoCliente
            // 
            this.btnNuevoCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnNuevoCliente.FlatAppearance.BorderSize = 0;
            this.btnNuevoCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoCliente.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnNuevoCliente.ForeColor = System.Drawing.Color.White;
            this.btnNuevoCliente.Location = new System.Drawing.Point(20, 15);
            this.btnNuevoCliente.Name = "btnNuevoCliente";
            this.btnNuevoCliente.Size = new System.Drawing.Size(120, 32);
            this.btnNuevoCliente.TabIndex = 0;
            this.btnNuevoCliente.Text = "+ Nuevo Cliente";
            this.btnNuevoCliente.UseVisualStyleBackColor = false;
            // 
            // ClientesUserControl
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.pnlRight);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.lblAdminDesc);
            this.Controls.Add(this.lblClientesTitle);
            this.Name = "ClientesUserControl";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(1300, 594);
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClienteAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblClientesTitle;
        private System.Windows.Forms.Label lblAdminDesc;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Button btnExportar;
        private System.Windows.Forms.ListView lstClientes;
        private System.Windows.Forms.ColumnHeader colFolio;
        private System.Windows.Forms.ColumnHeader colNombre;
        private System.Windows.Forms.ColumnHeader colContacto;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.PictureBox picClienteAvatar;
        private System.Windows.Forms.CheckBox chkTieneCredito;
        private System.Windows.Forms.TextBox txtLimiteCreditoMonto;
        private System.Windows.Forms.ComboBox cboLimiteCreditoTipo;
        private System.Windows.Forms.Label lblLimiteCredito;
        private System.Windows.Forms.TextBox txtNotas;
        private System.Windows.Forms.TextBox txtCodigoPostal;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.ComboBox cboMunicipio;
        private System.Windows.Forms.TextBox txtColonia;
        private System.Windows.Forms.TextBox txtDomicilio2;
        private System.Windows.Forms.TextBox txtDomicilio1;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtApellidos;
        private System.Windows.Forms.TextBox txtNombres;
        private System.Windows.Forms.Label lblNotas;
        private System.Windows.Forms.Label lblCodigoPostal;
        private System.Windows.Forms.Label lblMunicipioEstado;
        private System.Windows.Forms.Label lblColonia;
        private System.Windows.Forms.Label lblDomicilio2;
        private System.Windows.Forms.Label lblDomicilio1;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblApellidos;
        private System.Windows.Forms.Label lblNombres;
        private System.Windows.Forms.Label lblNuevoCliente;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevoCliente;
    }
}
