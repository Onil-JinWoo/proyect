using System;
using System.Data;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class departamentos : Form
    {
        public departamentos()
        {
            InitializeComponent();
            CargarDepartamentos();
        }

        private void CargarDepartamentos()
        {
            DataTable dt = DatabaseHelper.ObtenerDepartamentos();
            if (dt == null)
                dt = new DataTable();

            dgvDepartamentos.AutoGenerateColumns = false;
            dgvDepartamentos.DataSource = dt;
            btnEliminar.Enabled = dgvDepartamentos.Rows.Count > 0;
        }

        private void btnNuevoDepartamento_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtNombre.Focus();
        }

        private void btnGuardarDepartamento_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text == null ? string.Empty : txtNombre.Text.Trim();
            if (string.IsNullOrWhiteSpace(nombre))
            {
                MessageBox.Show("Por favor ingrese el nombre del departamento.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNombre.Focus();
                return;
            }

            if (DatabaseHelper.InsertarDepartamento(nombre))
            {
                CargarDepartamentos();
                txtNombre.Clear();
                txtNombre.Focus();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvDepartamentos.CurrentRow == null)
                return;

            object idValue = dgvDepartamentos.CurrentRow.Cells["colIdDepartamento"].Value;
            if (idValue == null)
                return;

            int id;
            if (!int.TryParse(idValue.ToString(), out id))
                return;

            string nombre = dgvDepartamentos.CurrentRow.Cells["colNombre"].Value == null
                ? string.Empty
                : dgvDepartamentos.CurrentRow.Cells["colNombre"].Value.ToString();

            DialogResult r = MessageBox.Show(
                string.Format("¿Eliminar el departamento '{0}'?", nombre),
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (r != DialogResult.Yes)
                return;

            if (DatabaseHelper.EliminarDepartamento(id))
                CargarDepartamentos();
        }
    }
}
